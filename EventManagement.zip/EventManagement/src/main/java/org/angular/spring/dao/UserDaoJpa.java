package org.angular.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;


import org.angular.spring.entity.Login;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Repository
public class UserDaoJpa implements UserDao {

	private EntityManager entityManager;

	public EntityManager getEntityManager() {

		return this.entityManager;
	}

	@PersistenceContext
	public void setEntityManager(final EntityManager entityManager) {

		this.entityManager = entityManager;
	}


	@Override
	@Transactional(readOnly = true)
	public List<Login> findAll() {

		final CriteriaBuilder builder = this.getEntityManager().getCriteriaBuilder();
		final CriteriaQuery<Login> criteriaQuery = builder.createQuery(Login.class);

		Root<Login> root = criteriaQuery.from(Login.class);
		criteriaQuery.orderBy(builder.desc(root.get("date")));

		TypedQuery<Login> typedQuery = this.getEntityManager().createQuery(criteriaQuery);
		return typedQuery.getResultList();
	}


	@Override
	@Transactional(readOnly = true)
	public Login find(Long id) {

		return this.getEntityManager().find(Login.class, id);
	}


	@Override
	@Transactional
	public Login save(Login obj) {
		return this.getEntityManager().merge(obj);
	}


	@Override
	@Transactional
	public void delete(Long id) {

		if (id == null) {
			return;
		}

		Login obj = this.find(id);
		if (obj == null) {
			return;
		}

		this.getEntityManager().remove(obj);
	}
	@Override
	@Transactional
	public List<Login> userIdByName(String name){
		
		return this.getEntityManager().createQuery("select l from Login l where l.username like :name ").setParameter("name", name).getResultList();
	}

}
