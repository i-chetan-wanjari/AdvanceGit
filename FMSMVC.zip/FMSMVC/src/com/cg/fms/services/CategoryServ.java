package com.cg.fms.services;

import java.util.List;
import com.cg.fms.pojos.Film;

public interface CategoryServ {
	List<Film> findByCategory(String category) throws Exception;
}
