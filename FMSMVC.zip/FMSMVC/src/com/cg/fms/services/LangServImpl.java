package com.cg.fms.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fms.exceptions.LanguageNotFound;
import com.cg.fms.jdbcrepo.RepoLang;
import com.cg.fms.pojos.Film;

@Service(value = "ServLang")
public class LangServImpl implements LangServ {

	@Autowired
	private RepoLang repo;

	@Override
	public List<Film> findByLanguage(String language) throws Exception {
		
		List<Film> f = repo.getFilmByLanguage(language);
		if (language == null || f.size() == 0)
			throw new LanguageNotFound();
		// TODO Auto-generated method stub
		return f;
	}
}
