package com.cg.TestSearch;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.cg.ems.service.SearchService;
import com.cg.ems.service.SearchServiceImpl;

public class SearchTestCasesForTitle {

	GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanConfig.xml");
	SearchService sserv = ctx.getBean("sservice",SearchServiceImpl.class);
	@Test
	public void displayEventForValidTitle()
	{
        
		sserv.findByName("Music");
	}
	
	@Test
	public void doNotDisplayeventForInvalidTitle()
	{
		assertFalse(sserv.findByName("ABX").size()>=1);
	}
	
	@Test
	public void doNotDisplayEventForNullTitle()
	{
		assertFalse(sserv.findByName(null).size()>=1);
	}

}

