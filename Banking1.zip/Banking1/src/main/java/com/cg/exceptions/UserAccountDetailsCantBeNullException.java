package com.cg.exceptions;

public class UserAccountDetailsCantBeNullException extends Exception{

}
