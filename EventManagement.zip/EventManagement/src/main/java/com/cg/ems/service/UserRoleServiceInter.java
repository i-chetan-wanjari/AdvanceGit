package com.cg.ems.service;

import com.cg.ems.pojo.UserRole;



public interface UserRoleServiceInter {
	UserRole saveRole(UserRole l) throws Exception;
}
