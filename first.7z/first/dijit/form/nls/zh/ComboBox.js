define(
({
		previousMessage: "先前选项",
		nextMessage: "更多选项"
})
);
