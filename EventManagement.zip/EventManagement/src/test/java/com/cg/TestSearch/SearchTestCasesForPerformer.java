package com.cg.TestSearch;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.cg.ems.service.SearchService;
import com.cg.ems.service.SearchServiceImpl;

public class SearchTestCasesForPerformer 
{

	GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanConfig.xml");
	SearchService sserv = ctx.getBean("sservice",SearchServiceImpl.class);
	@Test
	public void displayEventsWithValidPerformerOnly()
	{
		sserv.findByPerformer("asd","Adsf");
	}
	@Test
	public void doNotdisplayEventWithInvalidPerformer()
	{
		assertFalse(sserv.findByPerformer("cf", "asd").size()>=1);
		
	}

	@Test
	public void doNotdisplayEventIFPerformerFirstNameIsNull()
	{
		assertFalse(sserv.findByPerformer(null, "asd").size()>=1);
		
	}

	@Test
	public void doNotdisplayEventIFPerformerLastNameIsNull()
	{
		assertFalse(sserv.findByPerformer("asd", null).size()>=1);
		
	}

}
