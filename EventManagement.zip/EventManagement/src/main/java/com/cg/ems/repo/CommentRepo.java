package com.cg.ems.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.ems.pojo.Comment;

@Repository
public interface CommentRepo extends JpaRepository<Comment, Integer>{
	@Query(value="Select distinct(c) from Comment c left outer JOIN fetch c.replies r  where c.eventId=? and c.delete_date=0 ")
	public List<Comment> getComments(int id);
	
	@Query(value="Select distinct(c) from Comment c left outer JOIN fetch c.replies  where c.commentId=? and c.delete_date=0")
	public Comment findByCommentId(int id);
	
	
}
