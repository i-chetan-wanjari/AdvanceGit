package com.cg.pg.exception;

public class MerchantIdAndAmountIsMandatoryException extends Exception{

}
