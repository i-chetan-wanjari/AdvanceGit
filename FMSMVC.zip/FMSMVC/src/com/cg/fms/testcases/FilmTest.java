package com.cg.fms.testcases;

import static org.junit.Assert.*;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;

import org.junit.Test;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.cg.fms.exceptions.ActorNameCannotBeNull;
import com.cg.fms.exceptions.ActorShouldExistInFilm;
import com.cg.fms.exceptions.CategoryCannotBeNull;
import com.cg.fms.exceptions.FilmAlreadyExists;
import com.cg.fms.exceptions.FilmNotFound;
import com.cg.fms.exceptions.LanguageCannotBeNull;
import com.cg.fms.exceptions.RatingIsNull;
import com.cg.fms.exceptions.RatingNotFound;
import com.cg.fms.exceptions.ReleaseYearNotCorrect;
import com.cg.fms.exceptions.TitleCannotBeNull;
import com.cg.fms.pojos.Actor;
import com.cg.fms.pojos.Album;
import com.cg.fms.pojos.Category;
import com.cg.fms.pojos.Film;
import com.cg.fms.pojos.Language;
import com.cg.fms.pojos.Rating;
import com.cg.fms.services.FilmServ;
import com.cg.fms.services.FilmServImpl;

public class FilmTest {

	static GenericXmlApplicationContext context = new GenericXmlApplicationContext(
			"BeanConfig.xml");
	static FilmServ fService = context.getBean(FilmServ.class);
	static Date date = new Date();

	@Test
	public void creatingFilmSuccess() throws Exception {
		Film f = new Film();
		f.setTitle("DILWALE");
		Category c = new Category();
		c.setName("Drama");
		f.setCategory(c);
		f.setLength(50);
		f.setRating(Rating.PG_13);
		f.setRelease_year(2015);
		Album album = new Album();
		album.setAlbum_name("dilwale");
		f.setAlbum(album);
		Language l = new Language();
		l.setName("German");
		f.setLanguage(l);
		HashSet<Actor> actors = new HashSet<Actor>();
		Actor a = new Actor();
		a.setFirst_name("Kareena");
		a.setLast_name("Kapoor");
		a.setPhoto_url("1.jpg");
		actors.add(a);
		Actor a1 = new Actor();
		a1.setFirst_name("Shahid");
		a1.setLast_name("Kapoor");
		a1.setPhoto_url("2.jpg");
		actors.add(a1);
		f.setActors(actors);
		Date d = new Date();
		f.setLast_update(new Timestamp(d.getTime()));
		assertTrue(fService.saveFilm(f));
	}

	@Test
	public void modifyFilmSuccess() throws Exception {

		Film f = new Film();
		f.setTitle("Raid Redemption");
		Category c = new Category();
		c.setName("Sci-Fi");
		f.setCategory(c);
		f.setRating(Rating.NC_17);
		f.setRelease_year(2015);
		HashSet<Actor> actors = new HashSet<Actor>();
		Language l = new Language();
		l.setName("English");
		f.setLanguage(l);
		f.setRelease_year(2015);
		Album album = new Album();
		album.setAlbum_name("Album3");
		Actor a = new Actor();
		a.setFirst_name("Tonny");
		a.setLast_name("Stark");
		a.setPhoto_url("1.jpg");
		actors.add(a);
		Actor a1 = new Actor();
		a1.setFirst_name("Robert");
		a1.setLast_name("Downey");
		a1.setPhoto_url("2.jpg");
		actors.add(a1);
		f.setActors(actors);
		Date d = new Date();
		f.setLast_update(new Timestamp(d.getTime()));
		assertTrue(fService.changeFilm("Royy", f));
	}

	@Test
	public void removeFilm() throws Exception {
		 assertTrue(fService.deleteFilm("bahubali", new Timestamp(new Date().getTime())));
		 }

	@Test()
	public void searchFilmByTitle() throws Exception {
		assertTrue(fService.findFilmByName("ACADEMY DINOSAUR") != null);
	}

	@Test
	public void searchFilmByRating() throws Exception {
		assertTrue(fService.findFilmByRating("R").size() != 0);
	}

	@Test
	public void getAllFilms() throws Exception {
		assertTrue(fService.findAllFilm().size() != 0);
	}

	// SaveFilmWorstCases
	@Test(expected = TitleCannotBeNull.class)
	public void savingFilmTitleIsNull() throws Exception {
		Film f = new Film();
		Category c = new Category();
		c.setName("Sci-Fi");
		f.setCategory(c);
		f.setRating(Rating.PG_13);
		f.setRelease_year(2015);
		HashSet<Actor> actors = new HashSet<Actor>();
		Actor a = new Actor();
		Language l = new Language();
		l.setName("English");
		f.setLanguage(l);
		a.setFirst_name("Christian");
		a.setLast_name("Bale");
		a.setPhoto_url("1.jpg");
		actors.add(a);
		Actor a1 = new Actor();
		a1.setFirst_name("Bruce");
		a1.setLast_name("Wayne");
		a1.setPhoto_url("2.jpg");
		actors.add(a1);
		f.setActors(actors);
		Date d = new Date();
		f.setLast_update(new Timestamp(d.getTime()));
		fService.saveFilm(f);
		}

	@Test(expected = CategoryCannotBeNull.class)
	public void savingFilmCategoryIsNull() throws Exception {
		Film f = new Film();
		f.setTitle("Batman");
		f.setCategory(null);
		f.setRating(Rating.PG_13);
		f.setRelease_year(2015);
		HashSet<Actor> actors = new HashSet<Actor>();
		Actor a = new Actor();
		Language l = new Language();
		l.setName("English");
		f.setLanguage(l);
		a.setFirst_name("Christian");
		a.setLast_name("Bale");
		a.setPhoto_url("1.jpg");
		actors.add(a);
		Actor a1 = new Actor();
		a1.setFirst_name("Bruce");
		a1.setLast_name("Wayne");
		a1.setPhoto_url("2.jpg");
		actors.add(a1);
		f.setActors(actors);
		Date d = new Date();
		f.setLast_update(new Timestamp(d.getTime()));
		fService.saveFilm(f);
	}

	@Test(expected = ReleaseYearNotCorrect.class)
	public void savingFilmReleaseYearNotCorrect() throws Exception {
		Film f = new Film();
		f.setTitle("Batman");
		Category c = new Category();
		c.setName("Sci-Fi");
		f.setCategory(c);
		f.setRating(Rating.PG_13);
		f.setRelease_year(2019);
		HashSet<Actor> actors = new HashSet<Actor>();
		Actor a = new Actor();
		Language l = new Language();
		l.setName("English");
		f.setLanguage(l);
		a.setFirst_name("Christian");
		a.setLast_name("Bale");
		a.setPhoto_url("1.jpg");
		actors.add(a);
		Actor a1 = new Actor();
		a1.setFirst_name("Bruce");
		a1.setLast_name("Wayne");
		a1.setPhoto_url("2.jpg");
		actors.add(a1);
		f.setActors(actors);
		Date d = new Date();
		f.setLast_update(new Timestamp(d.getTime()));
		fService.saveFilm(f);

	}

	@Test(expected = LanguageCannotBeNull.class)
	public void savingFilmLanguageIsNull() throws Exception {
		Film f = new Film();
		f.setTitle("Batman");
		Category c = new Category();
		c.setName("Sci-Fi");
		f.setCategory(c);
		f.setRating(Rating.PG_13);
		f.setRelease_year(2015);
		;
		HashSet<Actor> actors = new HashSet<Actor>();
		Actor a = new Actor();
		Language l = new Language();
		l.setName(null);
		f.setLanguage(l);
		a.setFirst_name("Christian");
		a.setLast_name("Bale");
		a.setPhoto_url("1.jpg");
		actors.add(a);
		Actor a1 = new Actor();
		a1.setFirst_name("Bruce");
		a1.setLast_name("Wayne");
		a1.setPhoto_url("2.jpg");
		actors.add(a1);
		f.setActors(actors);
		Date d = new Date();
		f.setLast_update(new Timestamp(d.getTime()));
		fService.saveFilm(f);
	}

	@Test(expected = ActorNameCannotBeNull.class)
	public void savingFilmActorFirstNameIsNull() throws Exception {
		Film f = new Film();
		f.setTitle("Batman");
		Category c = new Category();
		c.setName("Sci-Fi");
		f.setCategory(c);
		f.setRating(Rating.PG_13);
		f.setRelease_year(2015);
		;
		HashSet<Actor> actors = new HashSet<Actor>();
		Actor a = new Actor();
		Language l = new Language();
		l.setName("English");
		f.setLanguage(l);
		a.setFirst_name(null);
		a.setLast_name("Bale");
		a.setPhoto_url("1.jpg");
		actors.add(a);
		Actor a1 = new Actor();
		a1.setFirst_name("Bruce");
		a1.setLast_name("Wayne");
		a1.setPhoto_url("2.jpg");
		actors.add(a1);
		f.setActors(actors);
		Date d = new Date();
		f.setLast_update(new Timestamp(d.getTime()));
		fService.saveFilm(f);
	}

	@Test(expected = ActorNameCannotBeNull.class)
	public void savingFilmActorLastNameIsNull() throws Exception {
		Film f = new Film();
		f.setTitle("Batman");
		Category c = new Category();
		c.setName("Sci-Fi");
		f.setCategory(c);
		f.setRating(Rating.PG_13);
		f.setRelease_year(2015);
		;
		HashSet<Actor> actors = new HashSet<Actor>();
		Actor a = new Actor();
		Language l = new Language();
		l.setName("English");
		f.setLanguage(l);
		a.setFirst_name("Christian");
		a.setLast_name("Bale");
		a.setPhoto_url("1.jpg");
		actors.add(a);
		Actor a1 = new Actor();
		a1.setFirst_name("Bruce");
		a1.setLast_name(null);
		a1.setPhoto_url("2.jpg");
		actors.add(a1);
		f.setActors(actors);
		Date d = new Date();
		f.setLast_update(new Timestamp(d.getTime()));
		fService.saveFilm(f);
	}

	@Test(expected = ActorShouldExistInFilm.class)
	public void savingFilmWithActorsNull() throws Exception {
		Film f = new Film();
		f.setTitle("Batman");
		Category c = new Category();
		c.setName("Sci-Fi");
		f.setCategory(c);
		f.setRating(Rating.PG_13);
		f.setRelease_year(2015);
		Language l = new Language();
		l.setName("English");
		f.setLanguage(l);
		Date d = new Date();
		f.setLast_update(new Timestamp(d.getTime()));
		fService.saveFilm(f);
	}

	@Test(expected = ActorNameCannotBeNull.class)
	public void savingFilmActorPhotoUrlIsNull() throws Exception {
		Film f = new Film();
		f.setTitle("Batman");
		Category c = new Category();
		c.setName("Sci-Fi");
		f.setCategory(c);
		f.setRating(Rating.PG_13);
		f.setRelease_year(2015);
		;
		HashSet<Actor> actors = new HashSet<Actor>();
		Actor a = new Actor();
		Language l = new Language();
		l.setName("English");
		f.setLanguage(l);
		a.setFirst_name("Christian");
		a.setLast_name("Bale");
		a.setPhoto_url("1.jpg");
		actors.add(a);
		Actor a1 = new Actor();
		a1.setFirst_name("Bruce");
		a1.setLast_name("Wayne");
		a1.setPhoto_url(null);
		actors.add(a1);
		f.setActors(actors);
		Date d = new Date();
		f.setLast_update(new Timestamp(d.getTime()));
		fService.saveFilm(f);
	}

	@Test (expected = FilmAlreadyExists.class)
	public void savingFilmWhichisAlreadyExist() throws Exception {

		Film f = new Film();
		f.setTitle("ACADEMY DINOSAUR");
		Category c = new Category();
		c.setName("Sci-Fi");
		f.setCategory(c);
		f.setRating(Rating.PG_13);
		f.setRelease_year(2015);
		HashSet<Actor> actors = new HashSet<Actor>();
		Language l = new Language();
		l.setName("English");
		f.setLanguage(l);
		Actor a = new Actor();
		a.setFirst_name("Robert");
		a.setLast_name("Downey");
		a.setPhoto_url("1.jpg");
		actors.add(a);
		Actor a1 = new Actor();
		a1.setFirst_name("Tonny");
		a1.setLast_name("Stark");
		a1.setPhoto_url("2.jpg");
		actors.add(a1);
		f.setActors(actors);
		Date d = new Date();
		f.setLast_update(new Timestamp(d.getTime()));
		fService.saveFilm(f);

	}

	// ChangeFilm
	@Test(expected = FilmNotFound.class)
	public void modifyFilmTitleIsNotFound() throws Exception {
		Film f = new Film();
		f.setTitle("Batman");
		Category c = new Category();
		c.setName("Sci-Fi");
		f.setCategory(c);
		f.setRating(Rating.PG_13);
		f.setRelease_year(2015);
		HashSet<Actor> actors = new HashSet<Actor>();
		Actor a = new Actor();
		Language l = new Language();
		l.setName("English");
		f.setLanguage(l);
		a.setFirst_name("Christian");
		a.setLast_name("Bale");
		a.setPhoto_url("1.jpg");
		actors.add(a);
		Actor a1 = new Actor();
		a1.setFirst_name("Bruce");
		a1.setLast_name("Wayne");
		a1.setPhoto_url("2.jpg");
		actors.add(a1);
		f.setActors(actors);
		Date d = new Date();
		f.setLast_update(new Timestamp(d.getTime()));
		fService.changeFilm("XYZ", f);
	}

	@Test(expected = FilmNotFound.class)
	public void modifyFilmTitleIsNull() throws Exception {
		Film f = new Film();
		f.setTitle("Batman");
		Category c = new Category();
		c.setName("Sci-Fi");
		f.setCategory(c);
		f.setRating(Rating.PG_13);
		f.setRelease_year(2015);
		;
		HashSet<Actor> actors = new HashSet<Actor>();
		Actor a = new Actor();
		Language l = new Language();
		l.setName("English");
		f.setLanguage(l);
		a.setFirst_name("Christian");
		a.setLast_name("Bale");
		a.setPhoto_url("1.jpg");
		actors.add(a);
		Actor a1 = new Actor();
		a1.setFirst_name("Bruce");
		a1.setLast_name("Wayne");
		a1.setPhoto_url("2.jpg");
		actors.add(a1);
		f.setActors(actors);
		Date d = new Date();
		f.setLast_update(new Timestamp(d.getTime()));
		fService.changeFilm(null, f);
	}

	// Delete Movie
	@Test(expected = FilmNotFound.class)
	public void deleteMovieTitleIsNull() throws Exception {
		fService.deleteFilm(null, null);
	}

	@Test(expected = FilmNotFound.class)
	public void deleteMovieTitleIsNotFound() throws Exception {
		fService.deleteFilm(" Happy New Year", new Timestamp(date.getTime()));
	}

	// SearchByName
	@Test(expected = FilmNotFound.class)
	public void searchByNameTitleIsNull() throws Exception {
		fService.findFilmByName(null);
	}

	@Test(expected = FilmNotFound.class)
	public void searchByNameTitleIsNotExist() throws Exception {
		fService.findFilmByName("ABCD Ironman");
	}

	// SearchByRating
	@Test(expected = RatingIsNull.class)
	public void searchByNameWhenRatingIsNull() throws Exception {
		fService.findFilmByRating(null);
	}

	@Test(expected = RatingNotFound.class)
	public void searchByNameRatingIsNotExist() throws Exception {
		fService.findFilmByRating("PN");
	}
}