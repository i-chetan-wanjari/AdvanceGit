package com.cg.exceptions;

public class MerchantAccountDetailsCantBeNullException extends Exception{

}
