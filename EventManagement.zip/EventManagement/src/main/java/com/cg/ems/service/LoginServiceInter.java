package com.cg.ems.service;

import com.cg.ems.pojo.Loginn;



public interface LoginServiceInter {
	Loginn saveLogin(Loginn l) throws Exception;
	boolean savePassword(int id, String password);

}
