package com.cg.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo.pojo.Employee;
import com.cg.demo.repo.EmployeeRepo;

@Service(value="empService")
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepo repo;
	@Override
	public List<Employee> findBySalary(double salary) {
		// TODO Auto-generated method stub
		return repo.findBySalary(salary);
	}
	@Override
	public Employee save(Employee e) {
		// TODO Auto-generated method stub
		return repo.saveAndFlush(e);
		
	}

}
