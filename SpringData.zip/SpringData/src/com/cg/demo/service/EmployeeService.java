package com.cg.demo.service;

import java.util.List;

import com.cg.demo.pojo.Employee;

public interface EmployeeService {
	List<Employee> findBySalary(double salary);
	
	Employee save(Employee e);
}
