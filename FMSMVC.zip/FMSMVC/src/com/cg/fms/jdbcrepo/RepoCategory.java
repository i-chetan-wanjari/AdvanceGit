package com.cg.fms.jdbcrepo;

import java.util.List;
import com.cg.fms.pojos.Category;
import com.cg.fms.pojos.Film;

public interface RepoCategory {
	
	boolean createCategory(Category c) throws Exception;
	boolean deleteCategory(String name) throws Exception;
	List<Film> getByCategory(String name) throws Exception;

}
