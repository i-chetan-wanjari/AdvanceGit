package com.cg.fms.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.fms.pojos.Film;
import com.cg.fms.services.ActorServImpl;
import com.cg.fms.services.CategoryServImpl;
import com.cg.fms.services.FilmServ;
import com.cg.fms.services.LangServImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class TitleController {

	@Autowired
	FilmServ filmserv;
	@Autowired
	LangServImpl langServ;
	@Autowired
	CategoryServImpl cateServ;
	@Autowired
	ActorServImpl actServ;
	@RequestMapping("/searchFilmByFilmTitle")
	public Film searchByFilmName(String title)throws Exception
	{
		return filmserv.findFilmByName(title);
	}
	@RequestMapping("/searchFilmByLanguage")
	public List<Film> searchFilmByLanguage(String name)throws Exception
	{
		return langServ.findByLanguage(name);
	}
	@RequestMapping("/searchFilmByRating")
	public List<Film> searchFilmByRating(String rating)throws Exception
	{
		return filmserv.findFilmByRating(rating);
	}
	@RequestMapping("/searchFilmByCategory")
	public List<Film> searchFilmByCategory(String cname)throws Exception
	{
		return cateServ.findByCategory(cname);
	}
	@RequestMapping("/searchFilmByActor")
	public List<Film> searchFilmByActor(String aname)throws Exception
	{
		return actServ.findFilmByActor(aname);
	}
	
}
