package com.cg.fms.exceptions;

public class RatingIsNull extends Exception {

}
