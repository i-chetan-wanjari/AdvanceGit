define(
({
		previousMessage: "Edelliset valinnat",
		nextMessage: "Lisää valintoja"
})
);
