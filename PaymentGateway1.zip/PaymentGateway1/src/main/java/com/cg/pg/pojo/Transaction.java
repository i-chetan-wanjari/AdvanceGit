package com.cg.pg.pojo;

public class Transaction {
private int id;
private int transactionId;
private String status;
private double amount;
private Merchant merchant;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public int getTransactionId() {
	return transactionId;
}
public void setTransactionId(int transactionId) {
	this.transactionId = transactionId;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
public Merchant getMerchant() {
	return merchant;
}
public void setMerchant(Merchant merchant) {
	this.merchant = merchant;
}
@Override
public String toString() {
	return "\n Transaction [id=" + id + ", transactionId=" + transactionId
			+ ", status=" + status + ", amount=" + amount + ", merchant="
			+ merchant + "]";
}

}
