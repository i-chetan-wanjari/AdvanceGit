package com.cg.ems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ems.pojo.Event;
import com.cg.ems.pojo.Rating;
import com.cg.ems.pojo.RatingVO;
import com.cg.ems.service.RatingService;



@RestController
public class RatingController {

	@Autowired
	RatingService rservice;
	
	
	@RequestMapping(value="/sratings")
	public List<RatingVO> searchRatings(String eventId)
	{
		return rservice.Ratingcollection(Integer.parseInt(eventId));	
	}
	
	@RequestMapping(value="/uratings")
	public boolean updateRatings(int eventId,int userId,int ratingValue)
	{	
		System.out.println(eventId + ""+userId + ""+ ratingValue);
		Rating rating=new Rating();
		rating.setEventId(eventId);
		rating.setUserId(userId);
		rating.setValue(ratingValue);
		return rservice.saveRating(rating);	
	}
	
}
