package com.cg.fms.jdbcrepo;

import java.util.List;
import com.cg.fms.pojos.Film;
import com.cg.fms.pojos.Language;

public interface RepoLang {

	boolean createLanguage(Language lang) throws Exception;
	List<Film> getFilmByLanguage(String lang) throws Exception;
	
}
 