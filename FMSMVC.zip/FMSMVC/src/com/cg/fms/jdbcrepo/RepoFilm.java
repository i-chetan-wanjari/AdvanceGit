package com.cg.fms.jdbcrepo;

import java.sql.Timestamp;
import java.util.List;

import com.cg.fms.pojos.Film;

public interface RepoFilm {

	boolean createFilm(Film f) throws Exception;
	boolean modifyFilm(String oldname, Film f) throws Exception;
	Film getFilmByName(String filmname) throws Exception;
	List<Film> getAllFilm() throws Exception;
	List<Film> getFilmByRating(String rating) throws Exception;
	String deleteFilm(String name, Timestamp timestamp) throws Exception;
}
