package com.cg.exceptions;

public class InvalidAccountNumber extends Exception {

}
