package com.cg.ems.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.ems.pojo.Loginn;

public interface LoginRepo extends JpaRepository<Loginn, Integer>{

}
