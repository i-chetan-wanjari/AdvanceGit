package com.cg.ems.service;

import java.util.List;

import com.cg.ems.pojo.EventVO;

public interface SearchService {
	List<EventVO> findByPerformer(String firstName,String lastName);
	List<EventVO> findByDate(String date);
	List<EventVO> findByRating();
	List<EventVO> findByCategory(String name);
	List<EventVO> findByCity(String city);
	List<EventVO> findByName(String eventName);
}
