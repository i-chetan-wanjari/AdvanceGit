package com.cg.demo.repo;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.demo.pojo.Employee;

public interface EmployeeRepo  extends JpaRepository<Employee, Integer>{

	@Query(value = "select e from Employee e where e.salary>?1")
	List<Employee> findBySalary(double salary);
}
