/*
SQLyog Enterprise - MySQL GUI v8.2 
MySQL - 5.0.45-community-nt : Database - ems_bankservices
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`ems_bankservices` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `ems_bankservices`;

/*Table structure for table `account` */

DROP TABLE IF EXISTS `account`;

CREATE TABLE `account` (
  `account_id` int(11) NOT NULL,
  `account_no` int(11) NOT NULL,
  `balance` double NOT NULL,
  `create_date` datetime default NULL,
  `delete_date` datetime default NULL,
  PRIMARY KEY  (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `account` */

insert  into `account`(`account_id`,`account_no`,`balance`,`create_date`,`delete_date`) values (1,1001,99994500,NULL,NULL),(2,1111,106500,NULL,NULL);

/*Table structure for table `customer` */

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `first_name` varchar(255) default NULL,
  `last_name` varchar(255) default NULL,
  `password` varchar(255) default NULL,
  `user_name` varchar(255) default NULL,
  `account_id` int(11) default NULL,
  PRIMARY KEY  (`customer_id`),
  KEY `FKeqp4idmxgvl1jq3bm0rkfiqy8` (`account_id`),
  CONSTRAINT `FKeqp4idmxgvl1jq3bm0rkfiqy8` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `customer` */

insert  into `customer`(`customer_id`,`first_name`,`last_name`,`password`,`user_name`,`account_id`) values (1,'sulochana','kalva','sulo@123','sulo',1),(2,'sagar','kulkarni','sagar','kulkarni',2);

/*Table structure for table `hibernate_sequence` */

DROP TABLE IF EXISTS `hibernate_sequence`;

CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hibernate_sequence` */

insert  into `hibernate_sequence`(`next_val`) values (93);

/*Table structure for table `transaction` */

DROP TABLE IF EXISTS `transaction`;

CREATE TABLE `transaction` (
  `bank_transaction_id` int(11) NOT NULL auto_increment,
  `amount` double NOT NULL,
  `available_balance` double NOT NULL,
  `create_date` datetime default NULL,
  `delete_date` datetime default NULL,
  `description` varchar(255) default NULL,
  `payment_transaction_id` varchar(255) default NULL,
  `status` varchar(255) default NULL,
  `transaction_type` varchar(255) default NULL,
  `account_id` int(11) default NULL,
  PRIMARY KEY  (`bank_transaction_id`),
  KEY `FK60ogq0ga4x4y0fkeu24tgm0kv` (`account_id`),
  CONSTRAINT `FK60ogq0ga4x4y0fkeu24tgm0kv` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=latin1;

/*Data for the table `transaction` */

insert  into `transaction`(`bank_transaction_id`,`amount`,`available_balance`,`create_date`,`delete_date`,`description`,`payment_transaction_id`,`status`,`transaction_type`,`account_id`) values (1,500,99999500,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Thu Jan 21 16:05:21 IST 2016','101PG','Success','Debit',1),(2,500,101500,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Thu Jan 21 16:05:21 IST 2016','101PG','Success','Credit',2),(3,500,99999000,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Thu Jan 21 16:05:42 IST 2016','101PG','Success','Debit',1),(4,500,102000,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Thu Jan 21 16:05:42 IST 2016','101PG','Success','Credit',2),(5,500,99998500,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Thu Jan 21 16:12:29 IST 2016','101PG','Success','Debit',1),(6,500,102500,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Thu Jan 21 16:12:29 IST 2016','101PG','Success','Credit',2),(7,500,99998000,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Thu Jan 21 16:13:21 IST 2016','101PG','Success','Debit',1),(8,500,103000,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Thu Jan 21 16:13:21 IST 2016','101PG','Success','Credit',2),(9,500,99997500,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Thu Jan 21 16:15:47 IST 2016','101PG','Success','Debit',1),(10,500,103500,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Thu Jan 21 16:15:47 IST 2016','101PG','Success','Credit',2),(11,500,99997000,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Thu Jan 21 16:16:14 IST 2016','101PG','Success','Debit',1),(12,500,104000,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Thu Jan 21 16:16:14 IST 2016','101PG','Success','Credit',2),(13,500,99996500,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Thu Jan 21 16:16:44 IST 2016','101PG','Success','Debit',1),(14,500,104500,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Thu Jan 21 16:16:44 IST 2016','101PG','Success','Credit',2),(15,500,99996000,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Thu Jan 21 16:16:59 IST 2016','101PG','Success','Debit',1),(16,500,105000,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Thu Jan 21 16:16:59 IST 2016','101PG','Success','Credit',2),(17,500,99995500,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Thu Jan 21 16:17:31 IST 2016','101PG','Success','Debit',1),(18,500,105500,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Thu Jan 21 16:17:31 IST 2016','101PG','Success','Credit',2),(19,500,99995000,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Thu Jan 21 16:21:18 IST 2016','101PG','Success','Debit',1),(20,500,106000,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Thu Jan 21 16:21:18 IST 2016','101PG','Success','Credit',2),(21,500,99994500,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Thu Jan 21 16:21:45 IST 2016','101PG','Success','Debit',1),(22,500,106500,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Thu Jan 21 16:21:45 IST 2016','101PG','Success','Credit',2),(23,500,99994000,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Thu Jan 21 16:22:04 IST 2016','101PG','Success','Debit',1),(24,500,107000,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Thu Jan 21 16:22:04 IST 2016','101PG','Success','Credit',2),(25,500,99993500,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Thu Jan 21 17:12:22 IST 2016','101PG','Success','Debit',1),(26,500,107500,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Thu Jan 21 17:12:22 IST 2016','101PG','Success','Credit',2),(27,500,99993000,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Thu Jan 21 17:44:54 IST 2016','101PG','Success','Debit',1),(28,500,108000,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Thu Jan 21 17:44:54 IST 2016','101PG','Success','Credit',2),(29,500,99992500,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Thu Jan 21 18:09:49 IST 2016','101PG','Success','Debit',1),(30,500,108500,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Thu Jan 21 18:09:49 IST 2016','101PG','Success','Credit',2),(31,500,99992000,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Thu Jan 21 18:12:06 IST 2016','101PG','Success','Debit',1),(32,500,109000,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Thu Jan 21 18:12:06 IST 2016','101PG','Success','Credit',2),(33,500,99991500,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Thu Jan 21 18:26:00 IST 2016','101PG','Success','Debit',1),(34,500,109500,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Thu Jan 21 18:26:00 IST 2016','101PG','Success','Credit',2),(35,500,99991000,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Fri Jan 22 09:01:35 IST 2016','101PG','Success','Debit',1),(36,500,110000,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Fri Jan 22 09:01:35 IST 2016','101PG','Success','Credit',2),(37,500,99990500,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Fri Jan 22 09:04:20 IST 2016','101PG','Success','Debit',1),(38,500,110500,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Fri Jan 22 09:04:20 IST 2016','101PG','Success','Credit',2),(39,500,99990000,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Fri Jan 22 09:14:38 IST 2016','101PG','Success','Debit',1),(40,500,111000,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Fri Jan 22 09:14:38 IST 2016','101PG','Success','Credit',2),(41,500,99989500,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Fri Jan 22 09:15:05 IST 2016','101PG','Success','Debit',1),(42,500,111500,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Fri Jan 22 09:15:05 IST 2016','101PG','Success','Credit',2),(43,500,99989000,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Fri Jan 22 09:48:16 IST 2016','101PG','Success','Debit',1),(44,500,112000,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Fri Jan 22 09:48:16 IST 2016','101PG','Success','Credit',2),(45,500,111500,NULL,NULL,'Amount of 500.0 was debited from your account 1111 on Fri Jan 22 11:42:18 IST 2016','101fs','Success','Debit',2),(46,500,99989500,NULL,NULL,'Amount of 500.0 was credited to your account 1001 on Fri Jan 22 11:42:18 IST 2016','101fs','Success','Credit',1),(47,500,111000,NULL,NULL,'Amount of 500.0 was debited from your account 1111 on Fri Jan 22 16:36:55 IST 2016','101fs','Success','Debit',2),(48,500,99990000,NULL,NULL,'Amount of 500.0 was credited to your account 1001 on Fri Jan 22 16:36:55 IST 2016','101fs','Success','Credit',1),(49,500,110500,NULL,NULL,'Amount of 500.0 was debited from your account 1111 on Fri Jan 22 17:09:39 IST 2016','101fs','Success','Debit',2),(50,500,99990500,NULL,NULL,'Amount of 500.0 was credited to your account 1001 on Fri Jan 22 17:09:39 IST 2016','101fs','Success','Credit',1),(51,500,110000,NULL,NULL,'Amount of 500.0 was debited from your account 1111 on Fri Jan 22 17:09:46 IST 2016','101fs','Success','Debit',2),(52,500,99991000,NULL,NULL,'Amount of 500.0 was credited to your account 1001 on Fri Jan 22 17:09:46 IST 2016','101fs','Success','Credit',1),(53,500,109500,NULL,NULL,'Amount of 500.0 was debited from your account 1111 on Fri Jan 22 17:14:50 IST 2016','101fs','Success','Debit',2),(54,500,99991500,NULL,NULL,'Amount of 500.0 was credited to your account 1001 on Fri Jan 22 17:14:50 IST 2016','101fs','Success','Credit',1),(55,500,109000,NULL,NULL,'Amount of 500.0 was debited from your account 1111 on Fri Jan 22 17:18:41 IST 2016','101fs','Success','Debit',2),(56,500,99992000,NULL,NULL,'Amount of 500.0 was credited to your account 1001 on Fri Jan 22 17:18:41 IST 2016','101fs','Success','Credit',1),(57,500,108500,NULL,NULL,'Amount of 500.0 was debited from your account 1111 on Fri Jan 22 17:19:40 IST 2016','101fs','Success','Debit',2),(58,500,99992500,NULL,NULL,'Amount of 500.0 was credited to your account 1001 on Fri Jan 22 17:19:40 IST 2016','101fs','Success','Credit',1),(59,500,108000,NULL,NULL,'Amount of 500.0 was debited from your account 1111 on Fri Jan 22 17:23:00 IST 2016','101fs','Success','Debit',2),(60,500,99993000,NULL,NULL,'Amount of 500.0 was credited to your account 1001 on Fri Jan 22 17:23:00 IST 2016','101fs','Success','Credit',1),(61,500,107500,NULL,NULL,'Amount of 500.0 was debited from your account 1111 on Fri Jan 22 17:24:30 IST 2016','101fs','Success','Debit',2),(62,500,99993500,NULL,NULL,'Amount of 500.0 was credited to your account 1001 on Fri Jan 22 17:24:30 IST 2016','101fs','Success','Credit',1),(63,500,107000,NULL,NULL,'Amount of 500.0 was debited from your account 1111 on Fri Jan 22 17:24:32 IST 2016','101fs','Success','Debit',2),(64,500,99994000,NULL,NULL,'Amount of 500.0 was credited to your account 1001 on Fri Jan 22 17:24:32 IST 2016','101fs','Success','Credit',1),(65,500,106500,NULL,NULL,'Amount of 500.0 was debited from your account 1111 on Fri Jan 22 17:24:46 IST 2016','101fs','Success','Debit',2),(66,500,99994500,NULL,NULL,'Amount of 500.0 was credited to your account 1001 on Fri Jan 22 17:24:46 IST 2016','101fs','Success','Credit',1),(67,500,106000,NULL,NULL,'Amount of 500.0 was debited from your account 1111 on Fri Jan 22 17:27:53 IST 2016','101fs','Success','Debit',2),(68,500,99995000,NULL,NULL,'Amount of 500.0 was credited to your account 1001 on Fri Jan 22 17:27:53 IST 2016','101fs','Success','Credit',1),(69,500,105500,NULL,NULL,'Amount of 500.0 was debited from your account 1111 on Fri Jan 22 17:52:15 IST 2016','101fs','Success','Debit',2),(70,500,99995500,NULL,NULL,'Amount of 500.0 was credited to your account 1001 on Fri Jan 22 17:52:15 IST 2016','101fs','Success','Credit',1),(71,500,105000,NULL,NULL,'Amount of 500.0 was debited from your account 1111 on Fri Jan 22 17:53:25 IST 2016','101fs','Success','Debit',2),(72,500,99996000,NULL,NULL,'Amount of 500.0 was credited to your account 1001 on Fri Jan 22 17:53:25 IST 2016','101fs','Success','Credit',1),(73,500,104500,NULL,NULL,'Amount of 500.0 was debited from your account 1111 on Fri Jan 22 18:01:08 IST 2016','101fs','Success','Debit',2),(74,500,99996500,NULL,NULL,'Amount of 500.0 was credited to your account 1001 on Fri Jan 22 18:01:08 IST 2016','101fs','Success','Credit',1),(75,500,104000,NULL,NULL,'Amount of 500.0 was debited from your account 1111 on Fri Jan 22 18:12:59 IST 2016','101fs','Success','Debit',2),(76,500,99997000,NULL,NULL,'Amount of 500.0 was credited to your account 1001 on Fri Jan 22 18:12:59 IST 2016','101fs','Success','Credit',1),(77,500,103500,NULL,NULL,'Amount of 500.0 was debited from your account 1111 on Fri Jan 22 18:18:25 IST 2016','101fs','Success','Debit',2),(78,500,99997500,NULL,NULL,'Amount of 500.0 was credited to your account 1001 on Fri Jan 22 18:18:25 IST 2016','101fs','Success','Credit',1),(79,500,103000,NULL,NULL,'Amount of 500.0 was debited from your account 1111 on Fri Jan 22 18:19:26 IST 2016','101fs','Success','Debit',2),(80,500,99998000,NULL,NULL,'Amount of 500.0 was credited to your account 1001 on Fri Jan 22 18:19:26 IST 2016','101fs','Success','Credit',1),(81,1000,99997000,NULL,NULL,'Amount of 1000.0 was debited from your account 1001 on Sat Jan 23 10:27:21 IST 2016','101fs','Success','Debit',1),(82,1000,104000,NULL,NULL,'Amount of 1000.0 was credited to your account 1111 on Sat Jan 23 10:27:21 IST 2016','101fs','Success','Credit',2),(83,500,99996500,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Sat Jan 23 10:42:34 IST 2016','101fs','Success','Debit',1),(84,500,104500,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Sat Jan 23 10:42:34 IST 2016','101fs','Success','Credit',2),(85,500,99996000,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Sat Jan 23 11:40:20 IST 2016','101fs','Success','Debit',1),(86,500,105000,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Sat Jan 23 11:40:20 IST 2016','101fs','Success','Credit',2),(87,500,99995500,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Sat Jan 23 11:40:25 IST 2016','101fs','Success','Debit',1),(88,500,105500,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Sat Jan 23 11:40:25 IST 2016','101fs','Success','Credit',2),(89,500,99995000,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Sat Jan 23 15:12:01 IST 2016','101fs','Success','Debit',1),(90,500,106000,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Sat Jan 23 15:12:01 IST 2016','101fs','Success','Credit',2),(91,500,99994500,NULL,NULL,'Amount of 500.0 was debited from your account 1001 on Sat Jan 23 15:12:31 IST 2016','101su','Success','Debit',1),(92,500,106500,NULL,NULL,'Amount of 500.0 was credited to your account 1111 on Sat Jan 23 15:12:31 IST 2016','101su','Success','Credit',2);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
