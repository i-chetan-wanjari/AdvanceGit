package com.cg.demo.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo.pojo.Project;
import com.cg.demo.repo.ProjectRepo;

@Service(value="projectService")
public class ProjectServiceImpl implements ProjectService{

	private ProjectRepo repo;
	
	@Autowired
	public ProjectServiceImpl(ProjectRepo repo) {
		super();
		this.repo = repo;
	}

	@Override
	@Transactional
	public String createProject(Project p) {
		// TODO Auto-generated method stub
		repo.save(p);
		return "Project created successfully!";
	}

}
