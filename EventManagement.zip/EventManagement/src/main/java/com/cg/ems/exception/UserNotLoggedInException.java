package com.cg.ems.exception;

public class UserNotLoggedInException extends Exception {

}
