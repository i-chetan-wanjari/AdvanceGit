package com.cg.ems.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.ems.pojo.Booking;
import com.cg.ems.pojo.BookingVO;
import com.cg.ems.pojo.Contact;
import com.cg.ems.pojo.EventVO;
import com.cg.ems.pojo.TicketType;
import com.cg.ems.pojo.User;

public interface BookingRepo extends JpaRepository<Booking, Integer> {
	


//
//	@Query(value="SELECT t FROM TicketType t WHERE t.ticketId=?1")
//	 public TicketType findTicketTypeById(int ticketId);
//	
//	
//@Query(value="select b from Booking b where b.userId=(:userId)")
//	public List<Booking> BookingsByUserId(@Param(value = "userId") int userId);
//
//
//@Query(value="select new com.cg.ems.pojo.BookingVO(b.noOfTickets,b.totalAmount,b.transactionId,b.bookingStatus) from Booking b where b.bookingId=(:bookingId)")
//public BookingVO BookingVoByBookingId(@Param(value = "bookingId") int bookingId);
//
//
//
//@Query(value="select t from  com.cg.ems.pojo.TicketType t where t.ticketId=(:ticketId)")	
//public TicketType tickettypeForBooking(@Param(value = "ticketId") int ticketId); 
//	
//@Query(value="select u from com.cg.ems.pojo.User u where u.userId=(:userId)")
//public User userOfBooking(@Param(value = "userId") int userId);
//
//@Query(value="select c from com.cg.ems.pojo.Contact c where c.eventid=(:eventId)")
//public List<Contact> contactList(@Param(value = "eventId") int eventId);
	
	@Query(value="select b FROM Booking b where b.bookingId=?1")
	public Booking bookingByBookingId(int bookingId);
	
	
	@Query(value="select new com.cg.ems.pojo.BookingVO(b.noOfTickets,b.totalAmount,b.transactionId,b.bookingStatus,b.eventId,b.userId,b.bookingId,b.ticketId) from Booking b where b.bookingId=?")
	public BookingVO BookingVo(int bookingId);
	
	@Query(value="select t from  com.cg.ems.pojo.TicketType t where t.ticketId=?")	
	public TicketType tickettypeForBooking(int id); 
	
	@Query(value="select u from com.cg.ems.pojo.User u where u.userId=?")
	public User userOfBooking(int id);
	
	@Query(value="select c from com.cg.ems.pojo.Contact c where c.eventid=?")
	public List<Contact> contactList(int id);
	
	@Query(value="SELECT new com.cg.ems.pojo.EventVO(e.eventId,e.eventName,c.name,e.status,e.avgRating,a.addressLine,a.city,ab.albumName,e.dateStart,e.dateEnd,ab.albumId) FROM Event e JOIN e.category c JOIN e.address a JOIN e.album ab  where e.eventId=?")
	public EventVO queryByEventId(int id);
	
	@Query(value="select p.photoUrl from com.cg.ems.pojo.PhotoCollection p where p.albumId=?")
	public List<String> photocollectionList(int albumId);

}
