package com.cg.ems.pojo;



import java.sql.Timestamp;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;


@Entity
public class Comment {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name ="comment_id")
	private int commentId;
	
	@ManyToOne
	@JoinColumn(name="user_id")
	private User user;
	
	@Column(name="event_id")
	private  int eventId;
	
	@Column(name="comment_text")
	private String commentText;
	
	@Column(name="last_update")
	private Timestamp lastUpdate;
	
	@OneToMany(fetch=FetchType.LAZY)
	@JoinColumn(name="comment_id")
	private List<Reply> replies;

	@Column(name="delete_date",insertable=false,updatable=true,nullable=true) 
	private Timestamp delete_date;
	public Timestamp getDelete_date() {
		return delete_date;
	}
	public void setDelete_date(Timestamp delete_date) {
		this.delete_date = delete_date;
	}
	
	public int getCommentId() {
		return commentId;
	}
	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
    public int getEventId() {
		return eventId;
	}
	public void setEventId(int eventId) {
		this.eventId = eventId;
	}
	public String getCommentText() {
		return commentText;
	}
	public void setCommentText(String commentText) {
		this.commentText = commentText;
	}
	public Timestamp getLastUpdate() {
		return lastUpdate;
	}
	public void setLastUpdate(Timestamp lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
	public List<Reply> getReplies() {
		return replies;
	}
	public void setReplies(List<Reply> replies) {
		this.replies = replies;
	}
	@Override
	public String toString() {
		return "Comment [commentId=" + commentId + ", user=" + user
				+ ", eventId=" + eventId + ", commentText=" + commentText
				+ ", lastUpdate=" + lastUpdate + ", replies=" + replies + "]";
	}
	
}
