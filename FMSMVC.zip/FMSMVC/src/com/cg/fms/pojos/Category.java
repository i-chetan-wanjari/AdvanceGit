package com.cg.fms.pojos;

public class Category {
	private int category_id;
	private String name;
	private boolean delete_update;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Category [category_id=" + category_id + ", name=" + name
				+ ", delete_update=" + delete_update + "]";
	}
	public boolean isDelete_update() {
		return delete_update;
	}
	public void setDelete_update(boolean delete_update) {
		this.delete_update = delete_update;
	}
	public int getCategory_id() {
		return category_id;
	}
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}
	
}
