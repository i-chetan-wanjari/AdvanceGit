package com.cg.ems.service;

import java.util.List;

import com.cg.ems.pojo.Event;
import com.cg.ems.pojo.Rating;
import com.cg.ems.pojo.RatingVO;

public interface RatingService {
	
	public List<RatingVO> Ratingcollection(int eventId);
	public boolean ChangeRating(int eventId);
	public boolean saveRating(Rating rating);
}
