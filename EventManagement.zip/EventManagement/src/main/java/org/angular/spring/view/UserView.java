package org.angular.spring.view;

import java.util.Map;

public class UserView {

	private final String name;

	private final Map<String, Boolean> roles;

	private final String token;
     private final Long id;

	public UserView(String userName, Map<String, Boolean> roles, String token,Long id) {
		this.name = userName;
		this.roles = roles;
		this.token = token;
		this.id=id;
	}


	public Long getId() {
		return id;
	}


	public String getName() {
		return this.name;
	}


	public Map<String, Boolean> getRoles() {
		return this.roles;
	}


	public String getToken() {
		return this.token;
	}


	@Override
	public String toString() {
		return "UserView [name=" + name + ", roles=" + roles + ", token="
				+ token + ", id=" + id + "]";
	}

}