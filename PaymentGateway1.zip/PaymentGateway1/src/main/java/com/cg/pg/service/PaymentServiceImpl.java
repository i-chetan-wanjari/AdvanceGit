


package com.cg.pg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.pg.exception.MerchantIdAndAmountIsMandatoryException;
import com.cg.pg.exception.MerchantIdCanNotBeNullException;
import com.cg.pg.repo.PaymentRepo;
import com.cg.pg.util.TxnGenerator;

@Service("Service")
public class PaymentServiceImpl implements PaymentService {
                @Autowired
                PaymentRepo repo;
public String generateTxnId(int merchantId,double amount,int bookingId) throws MerchantIdAndAmountIsMandatoryException{
                if(merchantId!=0 && amount!=0 && bookingId!=0){
                                new TxnGenerator();
                                String txnId=TxnGenerator.generateTxn();
                                repo.saveTxnId(txnId, amount, merchantId,bookingId);
                                return txnId;
                }
                else {
                                throw new MerchantIdAndAmountIsMandatoryException();
                }
                
                
}
public int giveAccNumber(int merchantId) throws MerchantIdCanNotBeNullException{
                if(merchantId!=0) {
                                return repo.getAccNumber(merchantId);

                }
                else throw new MerchantIdCanNotBeNullException();
                }
public int saveStatus(String txnId,String status) throws statusCanNotBeNullException, TransactionIdCanNotBeNullException{
                if(txnId==null ){
                                throw new TransactionIdCanNotBeNullException();
                }
                else if(status==null) {
                                throw new statusCanNotBeNullException();
                }
                else {
                return repo.getStatus(txnId,status);

                }
}
}
