package com.cg.ems.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.pojo.Comment;
import com.cg.ems.pojo.User;
import com.cg.ems.repo.CommentRepo;
import com.cg.ems.repo.UserRepo;

@Service(value = "cservice")
public class CommentServiceImpl  implements CommentService{
	@Autowired
	CommentRepo crepo ;
	
	@Autowired
	UserRepo urepo;
	public Comment saveComment(Comment c) throws Exception {
		if(c.getCommentText().length()<=0){
		 throw new Exception();	
		}
		
		return crepo.save(c); 
	}
	
	public List<Comment> getAll(int eventId){
		return crepo.getComments(eventId);

	}
	
	public Comment findComment(){
		return crepo.findByCommentId(1);
	}
	
	public User findUser(int userId){
		return urepo.getUserProfile(userId);
			
	}
	
	public String deleteComment(int commentId , int userId) {
		Comment c = crepo.findByCommentId(commentId);
		if(c.getUser().getUserId()!=userId){
			return "You  dont have the privileges to delete";
		}
		Date date=new Date();
		java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(date.getTime());
        c.setDelete_date(currentTimestamp);
        crepo.save(c);
		return "deleted successfully";
		}
}
