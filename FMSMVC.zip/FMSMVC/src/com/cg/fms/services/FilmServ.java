package com.cg.fms.services;

import java.sql.Timestamp;
import java.util.List;

import com.cg.fms.pojos.*;

public interface FilmServ {
	boolean saveFilm(Film f) throws Exception;
	boolean changeFilm(String title,Film f) throws Exception;
	Film findFilmByName(String title) throws Exception;
	List<Film> findAllFilm() throws Exception;
	List<Film> findFilmByRating(String string) throws Exception;
	boolean deleteFilm(String title, Timestamp timestamp) throws Exception;
}
