package com.cg.ems.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
@Entity
public class Rating {
	 @Id
	    @GeneratedValue(strategy=GenerationType.AUTO)
	 @Column(name="rating_id")
	private int ratingId;
	private int value;
	@Column(name="event_id")
	private int eventId;
	@Column(name="user_id")
	private int userId;
	public int getRatingId() {
		return ratingId;
	}
	public void setRatingId(int ratingId) {
		this.ratingId = ratingId;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public int getEventId() {
		return eventId;
	}
	public void setEventId(int eventId) {
		this.eventId = eventId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	@Override
	public String toString() {
		return "Rating [ratingId=" + ratingId + ", value=" + value
				+ ", eventId=" + eventId + ", userId=" + userId + "]";
	}
	
	
	
	
	
	
	
	
	
}
