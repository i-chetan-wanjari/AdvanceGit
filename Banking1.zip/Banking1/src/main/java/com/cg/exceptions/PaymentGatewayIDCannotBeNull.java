package com.cg.exceptions;

public class PaymentGatewayIDCannotBeNull extends Exception {

}
