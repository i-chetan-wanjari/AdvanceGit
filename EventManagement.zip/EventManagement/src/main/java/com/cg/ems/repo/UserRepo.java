package com.cg.ems.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.JpaRepositoryConfigExtension;

import com.cg.ems.pojo.BookingVO;
import com.cg.ems.pojo.Contact;
import com.cg.ems.pojo.Event;
import com.cg.ems.pojo.EventVO;
import com.cg.ems.pojo.TicketType;
import com.cg.ems.pojo.User;

public interface UserRepo extends JpaRepository<User, Integer> {
	//Get User Profile
	@Query(value="select u from User u where u.userId=?1")
	public User getUserProfile(int id);
	
	//Get User added Events
	@Query(value="SELECT new com.cg.ems.pojo.EventVO(e.eventId,e.eventName,c.name,e.status,e.avgRating,a.addressLine,a.city,ab.albumName,e.dateStart,e.dateEnd,ab.albumId) FROM Event e JOIN e.category c JOIN e.address a JOIN e.album ab WHERE e.userId=?and (e.deleteDate=0 or e.deleteDate=null)")
	public List<EventVO> getUserAddedEvents(int id);
	
	//User Booked Events
	@Query(value="select new com.cg.ems.pojo.BookingVO(b.noOfTickets,b.totalAmount,b.transactionId,b.bookingStatus,b.eventId,b.userId,b.bookingId,b.ticketId) from Booking b where b.userId=?")
	public List<BookingVO> getUserBookedEvents(int id);
	@Query(value="select t from  com.cg.ems.pojo.TicketType t where t.ticketId=?")	
	public TicketType tickettypeForBooking(int id); 
	@Query(value="select u from com.cg.ems.pojo.User u where u.userId=?")
	public User userOfBooking(int id);
	@Query(value="select c from com.cg.ems.pojo.Contact c where c.eventid=?")
	public List<Contact> contactList(int id);
	@Query(value="SELECT new com.cg.ems.pojo.EventVO(e.eventId,e.eventName,c.name,e.status,e.avgRating,a.addressLine,a.city,ab.albumName,e.dateStart,e.dateEnd,ab.albumId) FROM Event e JOIN e.category c JOIN e.address a JOIN e.album ab  where e.eventId=?")
	public EventVO queryByEventId(int id);
	@Query(value="select p.photoUrl from com.cg.ems.pojo.PhotoCollection p where p.albumId=?")
	public List<String> photocollectionList(int albumId);
	
	//Change Password
	
}
