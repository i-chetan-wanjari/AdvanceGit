package com.cg.exceptions;

public class AccountDetailsCantBeNullException extends Exception{

}
