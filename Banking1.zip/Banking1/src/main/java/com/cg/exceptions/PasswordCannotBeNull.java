package com.cg.exceptions;

public class PasswordCannotBeNull extends Exception {

}
