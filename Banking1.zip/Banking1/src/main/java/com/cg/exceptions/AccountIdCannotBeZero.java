package com.cg.exceptions;

public class AccountIdCannotBeZero extends Exception {

}
