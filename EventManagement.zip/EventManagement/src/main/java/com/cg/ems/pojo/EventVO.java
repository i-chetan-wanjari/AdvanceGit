package com.cg.ems.pojo;

import java.util.ArrayList;
import java.util.List;




public class EventVO {
	
	private int eventId;
	private String eventName;
	private String categoryName;
	private String status;
    private float avgRating;
    private String addressLine;
    private String city;
    private String albumName;
    private String dateStart;
    private String dateEnd;
    private int albumId;
    
    private List<String> photoCollections = new ArrayList<String>();
	public EventVO(int eventId, String eventName, String categoryName,
			String status, float avgRating, String addressLine, String city,
			String albumName, String dateStart, String dateEnd,int albumId) {
		super();
		this.eventId = eventId;
		this.eventName = eventName;
		this.categoryName = categoryName;
		this.status = status;
		this.avgRating = avgRating;
		this.addressLine = addressLine;
		this.city = city;
		this.albumName = albumName;
		this.dateStart = dateStart;
		this.dateEnd = dateEnd;
		this.albumId=albumId;
	}
	public void setPhotoCollections(List<String> photoCollections) {
		this.photoCollections = photoCollections;
	}
	
	public int getAlbumId() {
		return albumId;
	}
	
	public int getEventId() {
		return eventId;
	}
	public String getEventName() {
		return eventName;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public String getStatus() {
		return status;
	}
	public float getAvgRating() {
		return avgRating;
	}
	public String getAddressLine() {
		return addressLine;
	}
	public String getCity() {
		return city;
	}
	public String getAlbumName() {
		return albumName;
	}
	public String getDateStart() {
		return dateStart;
	}
	public String getDateEnd() {
		return dateEnd;
	}
	public List<String> getPhotoCollections() {
		return photoCollections;
	}
	@Override
	public String toString() {
		return "EventVObjects [eventId=" + eventId + ", eventName=" + eventName
				+ ", categoryName=" + categoryName + ", status=" + status
				+ ", avgRating=" + avgRating + ", addressLine=" + addressLine
				+ ", city=" + city + ", albumName=" + albumName
				+ ", dateStart=" + dateStart + ", dateEnd=" + dateEnd
				+ ", photoCollections=" + photoCollections + "]";
	}
	
    

		
		
	
}

	

