package com.cg.exceptions;

public class UsernameCannotBeNull extends Exception{

}
