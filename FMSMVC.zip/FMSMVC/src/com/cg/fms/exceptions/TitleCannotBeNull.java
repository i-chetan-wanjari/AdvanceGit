package com.cg.fms.exceptions;

public class TitleCannotBeNull extends Exception {

}
