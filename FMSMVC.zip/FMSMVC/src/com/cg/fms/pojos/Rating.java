package com.cg.fms.pojos;

public enum Rating {
PG, G, NC_17, PG_13, R;
}
