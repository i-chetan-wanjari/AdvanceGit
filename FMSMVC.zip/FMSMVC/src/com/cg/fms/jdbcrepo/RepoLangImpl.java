package com.cg.fms.jdbcrepo;

import java.util.HashSet;
import java.util.List;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cg.fms.pojos.Album;
import com.cg.fms.pojos.Category;
import com.cg.fms.pojos.Film;
import com.cg.fms.pojos.Language;


@Repository (value="RepoLang")
public class RepoLangImpl implements RepoLang {
	HashSet<Language> language = new HashSet<Language>();

	@Autowired
	private DataSource dataSourceLang;

	public List<Film> getFilmByLanguage(String name){
		
		String sql = "SELECT * FROM film join language using(language_id) where language.name=?";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSourceLang);
		List<Film> films= jdbcTemplate.query(sql,
				BeanPropertyRowMapper.newInstance(Film.class), name);
		
		
		for(Film f: films){
			
			try{
				String sql1 = "Select * from film where title=?";
				Film film= jdbcTemplate.queryForObject(sql1,
						BeanPropertyRowMapper.newInstance(Film.class), f.getTitle());	
				 f.setCategory(jdbcTemplate.queryForObject("Select * from category where category_id=?", BeanPropertyRowMapper.newInstance(Category.class), film.getCategory_id()));
				 f.setLanguage(jdbcTemplate.queryForObject("Select * from language where language_id=?", BeanPropertyRowMapper.newInstance(Language.class), film.getLanguage_id()));
				 f.setAlbum(jdbcTemplate.queryForObject("Select * from album where album_id=?", BeanPropertyRowMapper.newInstance(Album.class), film.getAlbum_id()));
				
				
				}catch(EmptyResultDataAccessException e){
					return null;
				}
		}

		return films;
	
	}

	@Override
	public boolean createLanguage(Language lang) throws Exception {
		if (lang != null) {
			if (language.contains(lang)) {
				return false;
			}
			language.add(lang);
		}

		// TODO Auto-generated method stub
		return false;
	}

}