package com.cg.pg.service;

public class statusCanNotBeNullException extends Exception {

}
