package com.cg.ems.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.pojo.Reply;
import com.cg.ems.repo.ReplyRepo;



@Service(value="rservice")
public class ReplyServiceImpl implements  ReplyService {

	@Autowired
	ReplyRepo replyRepo;
	
	public Reply saveReply(Reply r) throws Exception {
		if(r.getReplyText().length()<=0){
			throw new Exception();
		}
		return replyRepo.save(r);
	}
    
}
