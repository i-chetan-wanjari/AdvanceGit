package com.cg.pg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cg.pg.exception.MerchantIdAndAmountIsMandatoryException;
import com.cg.pg.exception.MerchantIdCanNotBeNullException;
import com.cg.pg.service.PaymentService;
import com.cg.pg.service.TransactionIdCanNotBeNullException;
import com.cg.pg.service.statusCanNotBeNullException;
import com.cg.pg.util.CipherHelper;

@Controller
public class PaymentController {
                @Autowired
                PaymentService service;
                CipherHelper c=new CipherHelper();
                @RequestMapping("/very")
                public String SayHello(ModelMap map) {

                                map.addAttribute("message", "Hoppipola!!!" + "");
                                return "hello";

                }
                @RequestMapping("/redirect")
                public String paymentRequest(double amount,int merchantId,int bookingId,ModelMap map) throws MerchantIdCanNotBeNullException, MerchantIdAndAmountIsMandatoryException
                {
                                String txnId=service.generateTxnId(merchantId,amount,bookingId);
                    int accNo=service.giveAccNumber(merchantId);
                    map.addAttribute("amount",amount);
                    map.addAttribute("txnId",txnId);
                    map.addAttribute("accountNumber",accNo);
                                return "payment1";
                }
                @RequestMapping("/result")
                public String transactionStatus(String txId,String status,ModelMap map) throws statusCanNotBeNullException, TransactionIdCanNotBeNullException{

                map.addAttribute("bId",service.saveStatus(txId, status));
                                map.addAttribute("txnId",txId);
                                map.addAttribute("status",status);
                                return "status";
                }
                @RequestMapping("/encode")
                public @ResponseBody String encryptParameters(String input,String secretKey ) throws Exception{
          String encryptedData = c.cipher(secretKey, input);
          return encryptedData;
                }
                
                @RequestMapping("/decode")
                public @ResponseBody String decryptParameters(String input ,String secretKey ) throws Exception{
          String decryptedData = c.decipher(secretKey, input);
          return decryptedData;
                }
}
