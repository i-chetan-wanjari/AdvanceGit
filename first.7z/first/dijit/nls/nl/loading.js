define(
({
	loadingState: "Bezig met laden...",
	errorState: "Er is een fout opgetreden"
})
);
