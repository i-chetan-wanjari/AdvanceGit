package com.cg.fms.exceptions;

public class AlbumNameCannotBeNull extends Exception {

}
