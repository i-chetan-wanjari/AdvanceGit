package com.cg.fms.jdbcrepo;

import java.sql.Timestamp;
import java.util.List;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.TransientDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.fms.exceptions.FilmAlreadyDeleted;
import com.cg.fms.exceptions.FilmNotFound;
import com.cg.fms.pojos.Album;
import com.cg.fms.pojos.Category;
import com.cg.fms.pojos.Film;
import com.cg.fms.pojos.Language;

@Repository(value = "RepoFilm")
public class RepoFilmImpl implements RepoFilm {

	@Autowired
	private DataSource dataSourceFilms;
	
	@Override
	public boolean createFilm(Film f) {
		if (f != null) {
			try {
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSourceFilms);
				try {
					Film film = jdbcTemplate.queryForObject(
							"Select * from film where title=?",
							BeanPropertyRowMapper.newInstance(Film.class),
							f.getTitle());
					if (film.getAlbum_id()!= 0) {
						System.out.print("problem is here");
						return false;
					}
				} 
				catch (EmptyResultDataAccessException se) {

				}
				Album album = jdbcTemplate.queryForObject(
						"Select album_id from album where album_name=?",
						BeanPropertyRowMapper.newInstance(Album.class), f
								.getAlbum().getAlbum_name());
				System.out.println("got it"+album.getAlbum_id());

				Category cat = jdbcTemplate.queryForObject(
						"Select category_id from category where name=?",
						BeanPropertyRowMapper.newInstance(Category.class), f
								.getCategory().getName());

				System.out.println("got category"+cat.getCategory_id());

				Language lang = jdbcTemplate.queryForObject(
						"Select language_id from language where name=?",
						BeanPropertyRowMapper.newInstance(Language.class), f
								.getLanguage().getName());

				System.out.println("got lang"+lang.getLanguage_id());

				String sql = "INSERT INTO film(title,rating,category_id,language_id,album_id, release_year,length) VALUES(?, ?, ?, ?, ?,?,?)";
				int k=jdbcTemplate.update(sql, f.getTitle(),
						f.getRating().toString(), cat.getCategory_id(),
						lang.getLanguage_id(), album.getAlbum_id(), f.getRelease_year(),f.getLength());
				System.out.println("focus more");
				if(k>0)
				{
					System.out.println("richa problem is here. focus more");
					return true;
				}
			} catch (EmptyResultDataAccessException e) {
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSourceFilms);
				Category cat = jdbcTemplate.queryForObject(
						"Select category_id from category where name=?",
						BeanPropertyRowMapper.newInstance(Category.class), f
								.getCategory().getName());
				System.out.println(cat.getCategory_id());
				Language lang = jdbcTemplate.queryForObject(
						"Select language_id from language where name=?",
						BeanPropertyRowMapper.newInstance(Language.class), f
								.getLanguage().getName());
				System.out.println(lang.getLanguage_id());

				int i = jdbcTemplate.update(
						"Insert into album (album_name) values(?)", f.getAlbum().getAlbum_name());
				if (i != 0) {
					Album album = jdbcTemplate.queryForObject(
							"Select album_id from album where album_name=?",
							BeanPropertyRowMapper.newInstance(Album.class), f
									.getAlbum().getAlbum_name());
					String sql = "INSERT INTO film(title,rating,category_id,language_id,album_id, release_year,length) VALUES(?, ?, ?, ?, ?,?,?)";
					int j=jdbcTemplate.update(sql, f.getTitle(), f.getRating()
							.toString(), cat.getCategory_id(), lang
							.getLanguage_id(), album.getAlbum_id(),f.getRelease_year(),f.getLength());
							if(j>0){

						Film new_film = jdbcTemplate.queryForObject(
								"Select film_id from film where title=?",
								BeanPropertyRowMapper.newInstance(Film.class),
								f.getTitle());

						int new_film_id = new_film.getFilm_id();

						RepoActorImpl repoActor = new RepoActorImpl();
						repoActor.insertActor(f.getActors(), new_film_id, jdbcTemplate);
						return true;
					}

				}

			}
		}
		return false;
	}

	@Override
	public boolean modifyFilm(String oldname, Film f) throws Exception {
		if (oldname != null) {
			if (f != null) {
				try {
					System.out.println(f.getRelease_year());
					JdbcTemplate jdbcTemplate = new JdbcTemplate(
							dataSourceFilms);
					Film film = jdbcTemplate.queryForObject(
							"Select * from film where title=?",
							BeanPropertyRowMapper.newInstance(Film.class),
							oldname);
					System.out.println(film.getFilm_id());

					jdbcTemplate
							.update("update film set title=?,release_year=?,length=?,rating=? where film_id=?",
									f.getTitle(), f.getRelease_year(),
									f.getLength(), f.getRating().name(),
									film.getFilm_id());
				} catch (EmptyResultDataAccessException e) {
					return false;
				}
			}
		}
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public String deleteFilm(String name, Timestamp timestamp)
			throws FilmAlreadyDeleted, FilmNotFound {
		if (name != null) {
			try {
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSourceFilms);
				try {
					Film film = jdbcTemplate
							.queryForObject("Select * from film where title=?",
									BeanPropertyRowMapper
											.newInstance(Film.class), name);

					if (film.getDelete_update() != null) {
						throw new FilmAlreadyDeleted();
					}
				} catch (EmptyResultDataAccessException e) {
					throw new FilmNotFound();
				}
				if(jdbcTemplate.update(
						"update film set delete_update = where title=?",
						timestamp, name)!=0)
				return "Film Removed";
			} catch (TransientDataAccessException e) {
				throw new FilmNotFound();
			}
			// TODO Auto-generated method stub
		}
		return "Error Occurred";
	}

	@Override
	public Film getFilmByName(String filmname) throws Exception {

		try {
			String sql = "Select * from film where title=?";
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSourceFilms);
			Film f = jdbcTemplate.queryForObject(sql,
					BeanPropertyRowMapper.newInstance(Film.class), filmname);
			f.setCategory(jdbcTemplate.queryForObject(
					"Select * from category where category_id=?",
					BeanPropertyRowMapper.newInstance(Category.class),
					f.getCategory_id()));
			f.setLanguage(jdbcTemplate.queryForObject(
					"Select * from language where language_id=?",
					BeanPropertyRowMapper.newInstance(Language.class),
					f.getLanguage_id()));
			f.setAlbum(jdbcTemplate.queryForObject(
					"Select * from album where album_id=?",
					BeanPropertyRowMapper.newInstance(Album.class),
					f.getAlbum_id()));
			return f;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	@Override
	public List<Film> getFilmByRating(String rating) throws Exception {
		String sql = "Select * from film where rating=?";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSourceFilms);
		return jdbcTemplate.query(sql,
				BeanPropertyRowMapper.newInstance(Film.class), rating);

	}

	@Override
	public List<Film> getAllFilm() throws Exception {
		String sql = "Select * from film";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSourceFilms);
		return jdbcTemplate.query(sql,
				BeanPropertyRowMapper.newInstance(Film.class));
	}

	public static void insertFilm_Actor(int new_film_id, int actor_id) {
		// TODO Auto-generated method stub

	}
}