package com.cg.fms.exceptions;

public class CategoryNotFound extends Exception {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
