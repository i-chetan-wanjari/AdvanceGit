package com.cg.fms.exceptions;

public class ActorNotFound extends Exception {

}
