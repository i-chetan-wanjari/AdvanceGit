package com.cg.fms.exceptions;

public class FilmAlreadyDeleted extends Exception {

}
