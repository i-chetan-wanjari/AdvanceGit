package com.cg.fms.exceptions;

public class FilmAlreadyExists extends Exception {

}
