package com.cg.ems.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.pojo.UserRole;
import com.cg.ems.repo.UserRoleRepo;

@Service(value="userRoleService")
public class UserRoleServiceImpl implements UserRoleServiceInter {

	@Autowired
	UserRoleRepo repo;
	@Override
	public UserRole saveRole(UserRole l) throws Exception {


		return repo.save(l); 
	}

}
