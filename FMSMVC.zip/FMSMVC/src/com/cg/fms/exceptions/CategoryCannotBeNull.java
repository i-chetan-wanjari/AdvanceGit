package com.cg.fms.exceptions;

public class CategoryCannotBeNull extends Exception {

}
