package com.cg.pg.service;

public class TransactionIdCanNotBeNullException extends Exception {

}
