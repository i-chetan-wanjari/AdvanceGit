package com.cg.fms.jdbcrepo;

import java.util.List;
import java.util.Set;
import java.sql.SQLException;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cg.fms.pojos.Actor;
import com.cg.fms.pojos.Album;
import com.cg.fms.pojos.Category;
import com.cg.fms.pojos.Film;
import com.cg.fms.pojos.Language;

@Repository(value = "RepoActor")
public class RepoActorImpl implements RepoActor {
	@Autowired
	private DataSource dataSourceActor;

	public List<Actor> getActorByName(String name) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSourceActor);
		String sql = "select actor_id,first_name from actor where first_name=?";
		return jdbcTemplate.query(sql,
				BeanPropertyRowMapper.newInstance(Actor.class), name);
	}

	public List<Film> getFilmByActor(String firstname)
			throws ClassNotFoundException, SQLException {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSourceActor);
		String sql = "SELECT * FROM film s,film_actor fa,actor a WHERE s.film_id=fa.film_id AND fa.actor_id=a.actor_id AND a.first_name=?";
		List<Film> films = jdbcTemplate.query(sql,
				BeanPropertyRowMapper.newInstance(Film.class), firstname);
		for (Film f : films) {
			try {
				String sql1 = "Select * from film where title=?";
				Film film = jdbcTemplate.queryForObject(sql1,
						BeanPropertyRowMapper.newInstance(Film.class),
						f.getTitle());
				f.setCategory(jdbcTemplate.queryForObject(
						"Select * from category where category_id=?",
						BeanPropertyRowMapper.newInstance(Category.class),
						film.getCategory_id()));
				f.setLanguage(jdbcTemplate.queryForObject(
						"Select * from language where language_id=?",
						BeanPropertyRowMapper.newInstance(Language.class),
						film.getLanguage_id()));
				f.setAlbum(jdbcTemplate.queryForObject(
						"Select * from album where album_id=?",
						BeanPropertyRowMapper.newInstance(Album.class),
						film.getAlbum_id()));
				System.out.println(f);

			} catch (EmptyResultDataAccessException e) {
				return null;
			}
		}

		return films;

	}

	

	public boolean addActor(Set<Actor> actors, int film_id) throws Exception {

		// TODO Auto-generated method stub
		return false;
	}

	public boolean insertActor(Set<Actor> actors, int new_film_id, JdbcTemplate jdbcTemplate) {
		if (new_film_id != 0) {
			if (actors != null) {
				for (Actor a : actors) {
					try {
						Actor actor = jdbcTemplate
								.queryForObject(
										"Select * from actor where first_name=? and last_name=?",
										BeanPropertyRowMapper
												.newInstance(Actor.class), a
												.getFirst_name(), a
												.getLast_name());
						if (jdbcTemplate.update("INSERT INTO film_actor(film_id,actor_id) VALUES(?,?)",
										new_film_id, actor.getActor_id()) != 0)
							return true;

					} catch (EmptyResultDataAccessException se) {

						int i = jdbcTemplate
								.update("Insert into actor(first_name,last_name) values(?,?)",
										a.getFirst_name(), a.getLast_name());
						System.out.println("hi not yet reached here");
						if (i != 0){
							Actor actor=jdbcTemplate
									.queryForObject(
											"Select * from actor where first_name=?",
											BeanPropertyRowMapper
													.newInstance(Actor.class), a
													.getFirst_name()
													);
							int k=jdbcTemplate.update("INSERT INTO film_actor(film_id,actor_id) VALUES(?,?)",
									new_film_id, actor.getActor_id());
							
							if ( k!= 0) {
								System.out.println("hi reached here");						
								return true;
							}
							}
					}
				}
			}
		}
		return false;
		// TODO Auto-generated method stub

	}
}