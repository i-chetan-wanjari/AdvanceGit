package com.cg.demo.service;

import com.cg.demo.pojo.Address;

public interface AddressService {
	public Address saveAddress(Address address);
}
