package com.cg.demo.service;

import com.cg.demo.pojo.Project;

public interface ProjectService {

	String createProject(Project p);
}
