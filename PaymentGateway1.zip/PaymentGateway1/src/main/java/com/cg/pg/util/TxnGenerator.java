package com.cg.pg.util;

public class TxnGenerator {
static int mid=001; 
static String first="ASAR";
static int num=00;
static String last="TX";
	public static String generateTxn(){
	       num++;
	       if(num>20){
	    	   num=0;
	    	   mid++;
	       }
	       return first+mid+last+num;
}
}
