package com.cg.fms.exceptions;

public class LanguageCannotBeNull extends Exception {

}
