package com.cg.fms.exceptions;

public class RatingNotFound extends Exception {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
