package com.cg.fms.jdbcrepo;

import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cg.fms.pojos.Album;
import com.cg.fms.pojos.Category;
import com.cg.fms.pojos.Film;
import com.cg.fms.pojos.Language;

@Repository (value="RepoCategory")
public class RepoCategoryImpl implements RepoCategory {
	static HashSet<Category> categories = new HashSet<Category>();
	

	@Autowired
	private DataSource dataSourceCategory;
	
	public List<Film> getByCategory(String name) throws ClassNotFoundException,
			SQLException {
		String sql = "SELECT * FROM film join category using(Category_id) where category.name=?";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSourceCategory);
		List<Film> films= jdbcTemplate.query(sql,
				BeanPropertyRowMapper.newInstance(Film.class), name);
		for(Film f: films){
			try{
				String sql1 = "Select * from film where title=?";
				Film film= jdbcTemplate.queryForObject(sql1,
						BeanPropertyRowMapper.newInstance(Film.class), f.getTitle());	
				 f.setCategory(jdbcTemplate.queryForObject("Select * from category where category_id=?", BeanPropertyRowMapper.newInstance(Category.class), film.getCategory_id()));
				 f.setLanguage(jdbcTemplate.queryForObject("Select * from language where language_id=?", BeanPropertyRowMapper.newInstance(Language.class), film.getLanguage_id()));
				 f.setAlbum(jdbcTemplate.queryForObject("Select * from album where album_id=?", BeanPropertyRowMapper.newInstance(Album.class), film.getAlbum_id()));
				 System.out.println(f);
				
				}catch(EmptyResultDataAccessException e){
					return null;
				}
		}

		return films;

}

	@Override
	public boolean createCategory(Category c) throws Exception {
		if (c != null) {
			if (categories.contains(c)) {
				return false;
			}
			categories.add(c);
		}
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCategory(String name) throws Exception {
		if (name != null) {
			for (Category category : categories) {
				if (category.getName().equals(name)) {
					category.setDelete_update(true);
				}
			}
		}
		// TODO Auto-generated method stub
		return true;
	}
}