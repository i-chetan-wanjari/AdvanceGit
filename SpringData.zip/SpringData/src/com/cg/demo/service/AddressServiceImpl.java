package com.cg.demo.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo.pojo.Address;
import com.cg.demo.repo.AddressRepo;
@Service(value="addressService")
public class AddressServiceImpl implements AddressService{

	private AddressRepo repo;
	
	@Autowired
	public AddressServiceImpl(AddressRepo repo) {
		super();
		this.repo = repo;
	}

	@Override
	@Transactional
	public Address saveAddress(Address address) {
		// TODO Auto-generated method stub
		
		//repo.saveAddress(address);
		
		repo.save(address);
		return address;
	}
}
