package PaymentGateway1.PaymentGateway1;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.cg.pg.exception.MerchantIdAndAmountIsMandatoryException;
import com.cg.pg.service.PaymentService;

public class PaymentGatewayTestCases {

	
	GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanConfig.xml");
	PaymentService service = ctx.getBean("Service",PaymentService.class);
	
	@Test(expected=MerchantIdAndAmountIsMandatoryException.class)
	public void merchantIdIsMandatory() throws MerchantIdAndAmountIsMandatoryException
	{
		service.generateTxnId(0, 5000, 123);
	}
	
	@Test(expected=MerchantIdAndAmountIsMandatoryException.class)
	public void bookingIdIsMandatory() throws MerchantIdAndAmountIsMandatoryException
	{
		service.generateTxnId(1, 5000, 0);
	}
	
	@Test(expected=MerchantIdAndAmountIsMandatoryException.class)
	public void amountIsMandatory() throws MerchantIdAndAmountIsMandatoryException
	{
		service.generateTxnId(1, 0, 123);
	}
	
	@Test(expected=MerchantIdAndAmountIsMandatoryException.class)
	public void allParametersInvalid() throws MerchantIdAndAmountIsMandatoryException
	{
		service.generateTxnId(0,0,0);
	}
	/*
	@Test
	public void validTransactionIdGeneration() throws MerchantIdAndAmountIsMandatoryException
	{
		assertTrue(service.generateTxnId(1, 500, 123).contains("Yes"));
	}*/


}
