package com.cg.fms.services;

import java.util.List;
import com.cg.fms.pojos.*;

public interface ActorServ {
boolean saveActor(Actor a) throws Exception;
boolean changeActor(String name, Actor a) throws Exception;
boolean deleteActor(String name) throws Exception;
List<Actor> findAllActor() throws Exception;
List<Film> findFilmByActor(String firstname) throws Exception;
}
