package com.cg.fms.services;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.fms.exceptions.*;
import com.cg.fms.jdbcrepo.RepoFilm;
import com.cg.fms.pojos.*;

@Service(value = "ServFilm")
public class FilmServImpl implements FilmServ {
	
	@Autowired
	RepoFilm repo;

	/*
	 * public FilmServImpl(RepoFilmImpl repo){ this.repo=repo; }
	 */

	public void filmValidation(Film f) throws Exception {
		if (f.getTitle() == null)
			throw new TitleCannotBeNull();
		if (f.getRelease_year() < 1950
				|| f.getRelease_year() > Calendar.getInstance().get(
						Calendar.YEAR))
			throw new ReleaseYearNotCorrect();
		if (f.getCategory() == null || f.getCategory().getName() == null)
			throw new CategoryCannotBeNull();
		if (f.getLanguage() == null || f.getLanguage().getName() == null)
			throw new LanguageCannotBeNull();
		if (f.getAlbum() == null)
			f.setAlbum(new Album());
		if (f.getAlbum().getAlbum_name() == null)
			f.getAlbum().setAlbum_name(f.getTitle());
		if (f.getActors() == null || f.getActors().size() == 0)
			throw new ActorShouldExistInFilm();
		for (Actor a : f.getActors())
			if (a.getFirst_name() == null || a.getLast_name() == null
					)
				throw new ActorNameCannotBeNull();
	}

	@Override
	public boolean saveFilm(Film f) throws Exception {
		// TODO Auto-generated method stub
		filmValidation(f);
		if (!repo.createFilm(f))
			throw new FilmAlreadyExists();
		return true;
	}

	@Override
	public boolean changeFilm(String title, Film f) throws Exception{
		// TODO Auto-generated method stub
		try {
			filmValidation(f);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (title == null || !repo.modifyFilm(title, f))
			throw new FilmNotFound();
		return true;
	}

	@Override
	public boolean deleteFilm(String title, Timestamp timestamp) throws Exception {
		if(title!=null)
		{
			if (repo.deleteFilm(title, timestamp)=="Film Removed")
				return true;
			if (repo.deleteFilm(title, timestamp)=="Error Occurred")
				return false;
		}
		else{
			throw new FilmNotFound();
		}
		return false;
	}

	@Override
	public Film findFilmByName(String title) throws Exception {
		if(title==null){
			throw new FilmNotFound();
		}
			// TODO Auto-generated method stub
		Film f = repo.getFilmByName(title);
		if (f == null)
			throw new FilmNotFound();
		return f;
	}

	@Override
	public List<Film> findFilmByRating(String rating) throws Exception {
		// TODO Auto-generated method stub
		if (rating != null) {
			List<Film> f = repo.getFilmByRating(rating);
			if (rating == null || f.size() == 0)
				throw new RatingNotFound();
			return f;
		}
		throw new RatingIsNull();
	}

	@Override
	public List<Film> findAllFilm() throws Exception {
		// TODO Auto-generated method stub
		return repo.getAllFilm();
	}

}
