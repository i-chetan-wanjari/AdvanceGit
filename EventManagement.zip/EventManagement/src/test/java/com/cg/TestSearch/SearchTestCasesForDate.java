package com.cg.TestSearch;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.cg.ems.service.SearchService;
import com.cg.ems.service.SearchServiceImpl;

public class SearchTestCasesForDate
{
	GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanConfig.xml");
	SearchService sserv = ctx.getBean("sservice",SearchServiceImpl.class);
	
	@Test
	public void displayEventsForValidDate()
	{
		sserv.findByDate("2016-01-22");
	}
	@Test
	public void doNotDisplayForInvalidDate()
	{
		assertFalse(sserv.findByDate("20-2016-22").size()>=1);
		
	}
	
	@Test
	public void doNotDisplayForNullDate()
	{
		assertFalse(sserv.findByDate(null).size()>=1);
		
	}

	
}
