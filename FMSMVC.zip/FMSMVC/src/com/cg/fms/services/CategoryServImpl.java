package com.cg.fms.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fms.exceptions.CategoryNotFound;
import com.cg.fms.jdbcrepo.RepoCategory;
import com.cg.fms.pojos.Film;

@Service(value = "ServCategory")
public class CategoryServImpl implements CategoryServ {
	
	@Autowired
	RepoCategory repo;

	/*
	 * public CategoryServImpl(RepoCategoryImpl repo) { this.repo = repo; }
	 */

	@Override
	public List<Film> findByCategory(String category) throws Exception {
		List<Film> f = repo.getByCategory(category);
		if (category == null || f.size() == 0)
			throw new CategoryNotFound();
		// TODO Auto-generated method stub
		return f;
	}
}