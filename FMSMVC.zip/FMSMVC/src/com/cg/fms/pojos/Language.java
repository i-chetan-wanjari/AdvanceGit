package com.cg.fms.pojos;

import java.sql.Timestamp;


public class Language {

private int language_id;
private String name;
private Timestamp last_update;
private Timestamp delete_update;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + language_id;
	result = prime * result + ((name == null) ? 0 : name.hashCode());
	return result;
}
@Override
public String toString() {
	return "Language [language_id=" + language_id + ", name=" + name
			+ ", last_update=" + last_update + ", delete_update="
			+ delete_update + "]";
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Language other = (Language) obj;
	if (language_id != other.language_id)
		return false;
	if (name == null) {
		if (other.name != null)
			return false;
	} else if (!name.equals(other.name))
		return false;
	return true;
}
public Timestamp isDelete_update() {
	return delete_update;
}
public void setDelete_update(Timestamp delete_update) {
	this.delete_update = delete_update;
}
public int getLanguage_id() {
	return language_id;
}
public void setLanguage_id(int language_id) {
	this.language_id = language_id;
}
public Timestamp getLast_update() {
	return last_update;
}
public void setLast_update(Timestamp last_update) {
	this.last_update = last_update;
}
}

