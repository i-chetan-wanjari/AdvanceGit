package com.cg.fms.jdbcrepo;

import java.util.List;
import com.cg.fms.pojos.Film;

public interface RepoActor {
	List<Film> getFilmByActor(String firstname) throws Exception;
}
