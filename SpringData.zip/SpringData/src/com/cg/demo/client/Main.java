package com.cg.demo.client;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.support.GenericXmlApplicationContext;

import com.cg.demo.pojo.Address;
import com.cg.demo.pojo.Employee;
import com.cg.demo.pojo.Project;
import com.cg.demo.service.EmployeeService;
import com.cg.demo.service.ProjectService;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanConfig.xml");
		Employee e1 = new Employee();
		//e1.setId(1);
		e1.setName("Vikram");
		e1.setSalary(150000);
		List<Address> ls1 = new ArrayList<Address>();
		
		Address address1 = new Address();
		address1.setLine("Talawade Village.");
		Address address2 = new Address();
		address2.setLine("Vazirabad, Nanded");
		
		ls1.add(address1);
		ls1.add(address2);
		
		e1.setAddresses(ls1);
		
		/*Employee e2 = new Employee();
		e2.setId(2);
		e2.setName("Saurabh");
		e2.setSalary(150);

		Employee e3 = new Employee();
		e3.setId(3);
		e3.setName("Amruta");
		e3.setSalary(76544);
*/
		EmployeeService es = ctx.getBean("empService", EmployeeService.class);
		e1 = es.save(e1);
/*		e2 = es.save(e2);
		e3 = es.save(e3);
*/


/*		AddressService addressService = ctx.getBean("addressService", AddressService.class); 
		addressService.saveAddress(address1);
		addressService.saveAddress(address2);
*/		

		/*Project p1 = new Project();
		p1.setName("HSBC");
		List<Employee> l1 = new ArrayList<Employee>();
		l1.add(e1);
		l1.add(e2);
		p1.setEmployees(l1);
		
		Project p2 = new Project();
		p2.setName("Barclays");
		List<Employee> l2 = new ArrayList<Employee>();
		l2.add(e1);
		l2.add(e2);
		l2.add(e3);
		p2.setEmployees(l2);
		ProjectService projectService  = ctx.getBean("projectService", ProjectService.class);
   projectService.createProject(p1);
	projectService.createProject(p2);*/
		
		
		System.out.println(es.findBySalary(50000));
		ctx.close();
		
	}

}
