package com.cg.service;

public interface CustomerServiceInterface {
	
	boolean ValidateUser(String user_name, String password );

}
