package com.cg.fms.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fms.exceptions.ActorNotFound;
import com.cg.fms.jdbcrepo.RepoActor;
import com.cg.fms.jdbcrepo.RepoActorImpl;
import com.cg.fms.pojos.Actor;
import com.cg.fms.pojos.Film;

@Service(value = "ServActor")
public class ActorServImpl implements ActorServ {

	@Autowired
	RepoActorImpl repo;

	@Override
	public List<Film> findFilmByActor(String firstname) throws Exception {

		List<Film> f = repo.getFilmByActor(firstname);

		if (firstname == null || f.size() == 0) {
			throw new ActorNotFound();
		}
		// TODO Auto-generated method stub
		return f;
	}
	public List<Actor> findActorByName(String name){
		System.out.println(name);
		if(name!=null){
			return repo.getActorByName(name);
		}
		return null;
	}

	@Override
	public boolean saveActor(Actor a) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean changeActor(String name, Actor a) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteActor(String name) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Actor> findAllActor() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
}
