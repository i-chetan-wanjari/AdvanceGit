package com.cg.fms.pojos;

import java.security.Timestamp;
import java.util.HashSet;

public class FilmActor {

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((actor == null) ? 0 : actor.hashCode());
		result = prime * result + actor_id;
		result = prime * result + film_id;
		result = prime * result
				+ ((last_update == null) ? 0 : last_update.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FilmActor other = (FilmActor) obj;
		if (actor == null) {
			if (other.actor != null)
				return false;
		} else if (!actor.equals(other.actor))
			return false;
		if (actor_id != other.actor_id)
			return false;
		if (film_id != other.film_id)
			return false;
		if (last_update == null) {
			if (other.last_update != null)
				return false;
		} else if (!last_update.equals(other.last_update))
			return false;
		return true;
	}

	private int actor_id;
	private int film_id;
	private Actor actor;
	public static HashSet<Film> filmActor = new HashSet<Film>();
	private Timestamp last_update;

	public HashSet<Film> getFilmActor() {
		return filmActor;
	}

	public void setFilmActor(HashSet<Film> filmActor) {
		FilmActor.filmActor = filmActor;
	}

	public Actor getActor() {
		return actor;
	}

	public void setActor(Actor actor) {
		this.actor = actor;
	}

	public int getActor_id() {
		return actor_id;
	}

	public void setActor_id(int actor_id) {
		this.actor_id = actor_id;
	}

	public int getFilm_id() {
		return film_id;
	}

	public void setFilm_id(int film_id) {
		this.film_id = film_id;
	}

	public Timestamp getLast_update() {
		return last_update;
	}

	public void setLast_update(Timestamp last_update) {
		this.last_update = last_update;
	}

}