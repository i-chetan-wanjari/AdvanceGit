
#=========== import important libraries ================
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# copy the data and save in text file.
# rename the text file as .csv file
#========= import the dataset ========================
data = pd.read_csv("data_chetan.csv").iloc[:,:-1]

#==========convert columns into string================
data["policy_bind_date"] = data["policy_bind_date"].astype("str")
data["incident_date"] = data["incident_date"].astype("str")

#===================        ===========================
stringColList = []
for i in data.columns:
    stringColList.append(str(i))
    
#=======================================================
#for i in stringColList:

def distinct_values(column):
    a = data[column].value_counts()
    aa = np.array([column,len(a)])
    return aa
distinct = []
for i in stringColList:
    ii = distinct_values(i)
    distinct.append(ii)
'''
[array(['months_as_customer', '391'], dtype='<U18'),
 array(['age', '46'], dtype='<U3'),
 array(['policy_number', '1000'], dtype='<U13'),
 array(['policy_bind_date', '951'], dtype='<U16'),
 array(['policy_state', '3'], dtype='<U12'),
 array(['policy_csl', '3'], dtype='<U10'),
 array(['policy_deductable', '3'], dtype='<U17'),
 array(['policy_annual_premium', '991'], dtype='<U21'),
 array(['umbrella_limit', '11'], dtype='<U14'),
 array(['insured_zip', '995'], dtype='<U11'),
 array(['insured_sex', '2'], dtype='<U11'),
 array(['insured_education_level', '7'], dtype='<U23'),
 array(['insured_occupation', '14'], dtype='<U18'),
 array(['insured_hobbies', '20'], dtype='<U15'),
 array(['insured_relationship', '6'], dtype='<U20'),
 array(['capital-gains', '338'], dtype='<U13'),
 array(['capital-loss', '354'], dtype='<U12'),
 array(['incident_date', '60'], dtype='<U13'),
 array(['incident_type', '4'], dtype='<U13'),
 array(['collision_type', '4'], dtype='<U14'),
 array(['incident_severity', '4'], dtype='<U17'),
 array(['authorities_contacted', '5'], dtype='<U21'),
 array(['incident_state', '7'], dtype='<U14'),
 array(['incident_city', '7'], dtype='<U13'),
 array(['incident_location', '1000'], dtype='<U17'),
 array(['incident_hour_of_the_day', '24'], dtype='<U24'),
 array(['number_of_vehicles_involved', '4'], dtype='<U27'),
 array(['property_damage', '3'], dtype='<U15'),
 array(['bodily_injuries', '3'], dtype='<U15'),
 array(['witnesses', '4'], dtype='<U9'),
 array(['police_report_available', '3'], dtype='<U23'),
 array(['total_claim_amount', '763'], dtype='<U18'),
 array(['injury_claim', '638'], dtype='<U12'),
 array(['property_claim', '626'], dtype='<U14'),
 array(['vehicle_claim', '726'], dtype='<U13'),
 array(['auto_make', '14'], dtype='<U9'),
 array(['auto_model', '39'], dtype='<U10'),
 array(['auto_year', '21'], dtype='<U9'),
 array(['fraud_reported', '2'], dtype='<U14')]

'''
#======= drop the distict columns from data ==============
cols = ['policy_number','policy_bind_date','insured_zip','incident_location','incident_type']
data = data.drop(cols,axis = 1)

#==========================================================

y = data["fraud_reported"]
print(y.value_counts())
'''
N    753
Y    247
Name: fraud_reported, dtype: int64
'''

print(display(data.groupby("fraud_reported").count()))
'''
                months_as_customer  age  ...  auto_model  auto_year
fraud_reported                           ...                       
N                              753  753  ...         753        753
Y                              247  247  ...         247        247

[2 rows x 33 columns]
'''

#======== convert categorical variables into numeric ======
a = (data.dtypes == object)
aa = data.dtypes[a == True]

'''
policy_state               object
policy_csl                 object
insured_sex                object
insured_education_level    object
insured_occupation         object
insured_hobbies            object
insured_relationship       object
incident_date              object
collision_type             object
incident_severity          object
authorities_contacted      object
incident_state             object
incident_city              object
property_damage            object
police_report_available    object
auto_make                  object
auto_model                 object
fraud_reported             object
'''


from sklearn.preprocessing import LabelEncoder
def labelencoder(column):
    labEnco = LabelEncoder()
    col = labEnco.fit_transform(column)
    return col
obj_cols = ['policy_state','policy_csl','insured_sex',
            'insured_education_level','insured_occupation',
            'insured_hobbies','insured_relationship',
            'incident_date','collision_type',
            'incident_severity','authorities_contacted',
            'incident_state','incident_city',
            'property_damage','police_report_available',
            'auto_make','auto_model','fraud_reported']
for i in obj_cols:
    data[i] = labelencoder(data[i])

#==== data spliting in dependent and independent variables========
    
X = data.drop('fraud_reported',axis = 1)
y = data['fraud_reported']

#==============================================================

from sklearn.model_selection import train_test_split

X_train,X_test,y_train,y_test = train_test_split(X,y,test_size = 0.2,random_state = 42 )

#############################################################

from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(n_estimators = 500,max_depth = 100)
model.fit(X_train,y_train)
y_pred = model.predict(X_test)

from sklearn.metrics import accuracy_score,confusion_matrix,f1_score

acc = accuracy_score(y_test,y_pred)
f1_sc = f1_score(y_test,y_pred)
print({"accuracy score":acc})

