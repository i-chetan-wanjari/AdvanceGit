package com.cg.pg.exception;

public class MerchantIdCanNotBeNullException extends Exception {

}
