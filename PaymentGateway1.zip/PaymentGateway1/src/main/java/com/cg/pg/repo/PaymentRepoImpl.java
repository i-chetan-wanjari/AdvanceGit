package com.cg.pg.repo;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository("Repository")
public class PaymentRepoImpl implements PaymentRepo {

                DataSource datasource;
                @Autowired
                public PaymentRepoImpl(DataSource datasource) {
                                super();
                                this.datasource = datasource;
                }
                JdbcTemplate jt;


                public int saveTxnId(String txnId, double amount, int merchantId,int bookingId) {
                                jt = new JdbcTemplate(datasource);
                                int accNo = jt.queryForObject(
                                                                "select accoutNumber from merchant where merchant_id=?",
                                                                new Object[] { merchantId }, Integer.class);
                                jt.update(
                                                                "insert into transaction(transaction_id,amount,merchant_id,booking_id) values(?,?,?,?)",
                                                                txnId, amount, merchantId,bookingId);
                                return accNo;

                }

                public int getAccNumber(int merchantId) {
                                jt = new JdbcTemplate(datasource);
                                return jt.queryForObject(
                                                                "select accoutNumber from merchant where merchant_id=?",
                                                                new Object[] { merchantId }, Integer.class);
                }
                public int getStatus(String txnId,String status){
                                jt = new JdbcTemplate(datasource);
                                jt.update("update transaction set status=? where transaction_id=?",status,txnId);
                                int bId = jt.queryForObject(
                                                                                "select booking_id from transaction where transaction_id=?",
                                                                                new Object[] { txnId }, Integer.class);
                                return bId;
                }

}
