package com.cg.demo.pojo;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Address {

		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private int id;
		private String line;
		/*@ManyToOne(fetch=FetchType.LAZY)
		//@JoinColumn(name="owner_id")
		private Employee owner;*/
		
		/*public Employee getEmployee() {
			return employee;
		}
		public void setEmployee(Employee employee) {
			this.employee = employee;
		}*/
		public String getLine() {
			return line;
		}
		public void setLine(String line) {
			this.line = line;
		}
		public int getId() {
			return id;
		}
		@Override
		public String toString() {
			return "Address [id=" + id + ", line=" + line + "]";
		}
		
		
}
