package com.cg.fms.testcases;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.cg.fms.exceptions.CategoryNotFound;
import com.cg.fms.services.CategoryServ;
import com.cg.fms.services.FilmServ;

public class CategoryTest {
	
	
	static GenericXmlApplicationContext context= new GenericXmlApplicationContext("BeanConfig.xml");
	static FilmServ fService= context.getBean(FilmServ.class);
	static CategoryServ cService= context.getBean(CategoryServ.class);
	@BeforeClass
	public static void saveData() throws Exception{
		/*Film f = new Film();
		f.setTitle("Ocean's 11");
		Category c = new Category();
		c.setName("Sci-Fi");
		f.setCategory(c);
		f.setRating(Rating.PG_13);
		f.setRelease_year(2015);;
		HashSet<Actor> actors =  new HashSet<Actor>();
		Language l = new Language();
		l.setName("English");
		Actor a = new Actor();
		a.setFirst_name("Brad");
		a.setLast_name("Pitt");
		a.setPhoto_url("1.jpg");
		actors.add(a);
		Actor a1 = new Actor();
		a1.setFirst_name("George");
		a1.setLast_name("Clooney");
		a1.setPhoto_url("2.jpg");
		actors.add(a1);
		f.setActors(actors);
		Date d = new Date();
		f.setLast_update(new Timestamp(d.getTime()));
		fService.saveFilm(f);
		
		Film f1 = new Film();
		f1.setTitle("POTF");
		Category c1 = new Category();
		c1.setName("Horror");
		f1.setCategory(c1);
		f1.setRating(Rating.G);
		f1.setRelease_year(2014);;
		HashSet<Actor> actors1 =  new HashSet<Actor>();
		Language l1 = new Language();
		l1.setName("English");
		f1.setLanguage(l1);
		Actor a2 = new Actor();
		a2.setFirst_name("Johnny");
		a2.setLast_name("Depp");
		a2.setPhoto_url("3.jpg");
		actors1.add(a2);
		Actor a3 = new Actor();
		a3.setFirst_name("Matt");
		a3.setLast_name("Damon");
		a3.setPhoto_url("4.jpg");
		actors1.add(a3);
		f1.setActors(actors1);
		Date d1 = new Date();
		f1.setLast_update(new Timestamp(d1.getTime()));
		System.out.println(fService.saveFilm(f1));
		System.out.println(f1.getCategory().getName());
		
	*/
	}
	@Test
	public void searchByCategorySuccess() throws Exception{
		System.out.println(cService.findByCategory("Horror").size());
		assertTrue(cService.findByCategory("Horror").size()!=0);
	}
	@Test(expected = CategoryNotFound.class)
	public void searchByCategoryIfCategoryIsNull() throws Exception{
		cService.findByCategory(null);
	}
	@Test(expected = CategoryNotFound.class)
	public void searchByCategoryIfCategoryIsNotFound() throws Exception{
		System.out.println(cService.findByCategory(null));
	}


}
