package com.cg.exceptions;

public class AccountNumberShouldNotBEZero extends Exception {

}
