package com.cg.fms.services;

import java.util.List;
import com.cg.fms.pojos.Film;

public interface LangServ {
	List<Film> findByLanguage(String language) throws Exception;
}
