package com.cg.ems.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.ems.pojo.Event;
import com.cg.ems.pojo.EventVO;

public interface SearchRepo extends JpaRepository<Event, Integer>{
	//Search By Performer
	@Query(value="SELECT new com.cg.ems.pojo.EventVO(e.eventId,e.eventName,c.name,e.status,e.avgRating,a.addressLine,a.city,ab.albumName,e.dateStart,e.dateEnd,ab.albumId) FROM Event e JOIN e.category c JOIN e.address a JOIN e.album ab JOIN e.performer p where p.firstName=?1 AND p.lastName=?2 and e.status='Approved' and  e.dateStart > now() and  (e.deleteDate=0 or e.deleteDate=null)")
	public List<EventVO> searchByPerformer(String firstName,String lastName);
	@Query(value="select p.photoUrl from com.cg.ems.pojo.PhotoCollection p where p.albumId=?")
	public List<String> photocollectionList(int albumId);
	
	//SearchByDate
	@Query(value="SELECT new com.cg.ems.pojo.EventVO(e.eventId,e.eventName,c.name,e.status,e.avgRating,a.addressLine,a.city,ab.albumName,e.dateStart,e.dateEnd,ab.albumId) FROM Event e JOIN e.category c JOIN e.address a JOIN e.album ab WHERE DATEDIFF(e.dateStart,?1)<=0 AND DATEDIFF(?1,e.dateEnd)<=0 and e.status='Approved'  and  e.dateStart > now() and  (e.deleteDate=0 or e.deleteDate=null)")
	public List<EventVO> searchByDate(String date);
	
	//SearchByRating
	@Query(value="SELECT new com.cg.ems.pojo.EventVO(e.eventId,e.eventName,c.name,e.status,e.avgRating,a.addressLine,a.city,ab.albumName,e.dateStart,e.dateEnd,ab.albumId) FROM Event e JOIN e.category c JOIN e.address a JOIN e.album ab where e.status='Approved'  and  e.dateStart > now() and  (e.deleteDate=0 or e.deleteDate=null) ORDER BY e.avgRating DESC")
	public List<EventVO> searchByRating();
	
	//SearchByCategory
	@Query(value="SELECT new com.cg.ems.pojo.EventVO(e.eventId,e.eventName,c.name,e.status,e.avgRating,a.addressLine,a.city,ab.albumName,e.dateStart,e.dateEnd,ab.albumId) FROM Event e JOIN e.category c JOIN e.address a JOIN e.album ab WHERE c.name=? and e.status='Approved'  and  e.dateStart > now() and  (e.deleteDate=0 or e.deleteDate=null)")
	public List<EventVO> searchByCategory(String name);
	
	//SearchByVenue
	@Query(value="SELECT new com.cg.ems.pojo.EventVO(e.eventId,e.eventName,c.name,e.status,e.avgRating,a.addressLine,a.city,ab.albumName,e.dateStart,e.dateEnd,ab.albumId) FROM Event e JOIN e.category c JOIN e.address a JOIN e.album ab WHERE a.city=? and e.status='Approved'  and  e.dateStart > now() and  (e.deleteDate=0 or e.deleteDate=null)")
	public List<EventVO> searchByCity(String city);
	
	//SearchByName
	@Query(value="SELECT new com.cg.ems.pojo.EventVO(e.eventId,e.eventName,c.name,e.status,e.avgRating,a.addressLine,a.city,ab.albumName,e.dateStart,e.dateEnd,ab.albumId) FROM Event e JOIN e.category c JOIN e.address a JOIN e.album ab WHERE e.eventName=? and e.status='Approved'  and  e.dateStart > now() and  (e.deleteDate=0 or e.deleteDate=null)")
	public List<EventVO> searchByName(String eventName);
}
