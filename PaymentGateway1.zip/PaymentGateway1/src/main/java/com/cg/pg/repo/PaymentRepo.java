package com.cg.pg.repo;

public interface PaymentRepo {
public int saveTxnId(String txnId,double amount,int merchantId,int bookingId);
public int getAccNumber(int merchantId);
public int getStatus(String txnId, String status);
}
