package com.cg.pg.service;

import com.cg.pg.exception.MerchantIdAndAmountIsMandatoryException;
import com.cg.pg.exception.MerchantIdCanNotBeNullException;

public interface PaymentService {
	public String generateTxnId(int merchantId,double amount,int bookingId) throws MerchantIdAndAmountIsMandatoryException;
	public int giveAccNumber(int merchantId) throws MerchantIdCanNotBeNullException;
	public int saveStatus(String txnId,String status) throws statusCanNotBeNullException, TransactionIdCanNotBeNullException;
}
