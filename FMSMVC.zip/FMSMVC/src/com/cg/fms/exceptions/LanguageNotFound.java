package com.cg.fms.exceptions;

public class LanguageNotFound extends Exception {

}
