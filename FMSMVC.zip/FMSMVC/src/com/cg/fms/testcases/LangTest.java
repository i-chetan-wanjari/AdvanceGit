package com.cg.fms.testcases;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.cg.fms.exceptions.LanguageNotFound;
import com.cg.fms.services.FilmServ;
import com.cg.fms.services.LangServ;


public class LangTest {


	static GenericXmlApplicationContext context= new GenericXmlApplicationContext("BeanConfig.xml");
	static FilmServ fService= context.getBean(FilmServ.class);
	static LangServ lService= context.getBean(LangServ.class);
	
	
	@BeforeClass
	public static void saveData() throws Exception{
		/*Film f = new Film();
		f.setTitle("Da Vinci Code");
		Category c = new Category();
		c.setName("Sci-Fi");
		f.setCategory(c);
		f.setRating(Rating.PG_13);
		f.setRelease_year(2015);;
		HashSet<Actor> actors =  new HashSet<Actor>();
		Language l = new Language();
		l.setName("English");
		f.setLanguage(l);
		Actor a = new Actor();
		a.setFirst_name("Tom");
		a.setLast_name("Hanks");
		a.setPhoto_url("1.jpg");
		actors.add(a);
		Actor a1 = new Actor();
		a1.setFirst_name("Robert");
		a1.setLast_name("Langden");
		a1.setPhoto_url("2.jpg");
		actors.add(a1);
		f.setActors(actors);
		Date d = new Date();
		f.setLast_update(new Timestamp(d.getTime()));
		fService.saveFilm(f);
		
		Film f1 = new Film();
		f1.setTitle("Ocean's 11");
		Category c1 = new Category();
		c1.setName("Horror");
		f1.setCategory(c1);
		f1.setRating(Rating.G);
		f1.setRelease_year(2014);;
		HashSet<Actor> actors1 =  new HashSet<Actor>();
		Language l1 = new Language();
		l1.setName("English");
		f1.setLanguage(l1);
		Actor a2 = new Actor();
		a2.setFirst_name("Brad");
		a2.setLast_name("Pitt");
		a2.setPhoto_url("3.jpg");
		actors1.add(a2);
		Actor a3 = new Actor();
		a3.setFirst_name("Matt");
		a3.setLast_name("damon");
		a3.setPhoto_url("4.jpg");
		actors1.add(a3);
		f1.setActors(actors1);
		Date d1 = new Date();
		f1.setLast_update(new Timestamp(d1.getTime()));
		System.out.println(fService.saveFilm(f1));*/
	}
	@Test
	public void searchByLanguageSuccess() throws Exception{
		System.out.println(lService.findByLanguage("English").size());
		assertTrue(lService.findByLanguage("English").size()!=0);
	}
	@Test(expected = LanguageNotFound.class)
	public void searchByLanguageIfLanguageIsNull() throws Exception{
		lService.findByLanguage(null);
	}
	@Test(expected = LanguageNotFound.class)
	public void searchByLanguageIfLanguageIsNotFound() throws Exception{
		lService.findByLanguage("Animation");
	}
}
