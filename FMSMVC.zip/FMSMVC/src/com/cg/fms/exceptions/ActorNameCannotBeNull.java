package com.cg.fms.exceptions;

public class ActorNameCannotBeNull extends Exception {

}
